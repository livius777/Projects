package utils;

import filesystem.FileSystemOperation;
import vcs.Vcs;
import vcs.VcsOperation;

public final class Context {
    private Vcs vcs;
    private static Context instance = null;
    private InputReader inputReader;
    private OutputWriter outputWriter;

    /**
     * Context constructor.
     */
    private Context() {
    }

    /**
     * Gets the instance.
     *
     * @return the instance
     */
    public static Context getInstance() {
        if (instance == null) {
            instance = new Context();
        }

        return instance;
    }

    /**
     * Initialise the vcs.
     *
     * @param input  the input file
     * @param output the output file
     */
    public void init(final String input, final String output) {
        inputReader = new InputReader(input);
        outputWriter = new OutputWriter(output);
        vcs = new Vcs(outputWriter);
    }

    /**
     * Runs the context.
     */
    public void run() {
        String operationString = "";
        AbstractOperation operation;
        OperationParser parser = new OperationParser();
        int exitCode;
        boolean wasError;

        this.vcs.init();

        while (true) {
            operationString = this.inputReader.readLine();
            if (operationString == null || operationString.isEmpty()) {
                continue;
            }
            if (operationString.equals("exit")) {
                return;
            }
            operation = parser.parseOperation(operationString);
            exitCode = operation.accept(vcs);
            wasError = ErrorCodeManager.getInstance().checkExitCode(outputWriter, exitCode);

            if (!wasError && this.isTrackable(operation)) {
                // TODO If the operation is trackable, vcs should track it
                //daca operatia a reusit atunci updatam stagedchanges
                switch (operation.type) {
                    case CHANGEDIR:
                        vcs.getCurrentBranch().getStagedChanges().
                        add("Changed directory to " + operation.operationArgs.get(0));
                        break;
                    case MAKEDIR:
                        vcs.getCurrentBranch().getStagedChanges().
                        add("Created directory " + operation.operationArgs.get(0));
                        break;
                    case REMOVE:
                        vcs.getCurrentBranch().getStagedChanges().
                        add("Removed " + ((operation.operationArgs.size() == 2)
                                ? operation.operationArgs.get(1) : operation.operationArgs.get(2)));
                    case TOUCH:
                        vcs.getCurrentBranch().getStagedChanges().
                        add("\t" + "Created file " + operation.operationArgs.get(1));
                        break;
                    case WRITETOFILE:
                        vcs.getCurrentBranch().getStagedChanges().
                        add("\t" + "Added " + "\"" + operation.operationArgs.get(1) + "\" to file "
                        + operation.operationArgs.get(0));
                        break;
                }
            }
        }
    }

    /**
     * Specifies if an operation is vcs trackable or not.
     * You can use it when you implement rollback/checkout -c functionalities.
     * @param abstractOperation the operation
     * @return whether it's trackable or not
     */
    private boolean isTrackable(final AbstractOperation abstractOperation) {
        boolean result;

        switch (abstractOperation.type) {
            case CHANGEDIR:
            case MAKEDIR:
            case REMOVE:
            case TOUCH:
            case WRITETOFILE:
                result = true;
                break;
            default:
                result = false;
        }

        return result;
    }
}
