package utils;

public enum EntityType {
    FILE,
    DIRECTORY
}
