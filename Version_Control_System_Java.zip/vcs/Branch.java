package vcs;
import java.util.LinkedList;
import filesystem.FileSystemSnapshot;
//clasa ce descrie un Branch
//acesta va contine numele branch-ului, commit-urile sale (relatie "has a")
//precum si stagedChanges, o lista de string-uri cu comenzile data de la ultimul commit
public class Branch {
    private String name;
    private LinkedList<Commit> commits;
    private LinkedList<String> stagedChanges;
    public Branch(final String name) {
        this.name = name;
        this.commits = new LinkedList<Commit>();
        this.stagedChanges = new LinkedList<String>();
    }
    //adaugare commit, stagedChanges este golit
    public final void addCommit(final Commit c) {
        commits.add(c);
        this.clearStagedChanges();
    }
    //functie care goleste stagedChanges
    public final void clearStagedChanges() {
        stagedChanges = new LinkedList<String>();
    }
    //getter name
    public final String getName() {
        return name;
    }
    //luam ultima stare salvata pe acest brach
    public final FileSystemSnapshot getCurrentState() {
        return commits.getLast().getFileSystemSnapshot();
    }
    //getter stagedChanges
    public final LinkedList<String> getStagedChanges() {
        return stagedChanges;
    }
    //getter commits
    public final LinkedList<Commit> getCommits() {
        return commits;
    }
    //functie care verifica existenta commit-ului cu id-ul "id" in lista de commit-uri
    public final boolean hasCommitWithId(final int id) {
        for (int i = commits.size() - 1; i >= 0; i--) {
            if (commits.get(i).getId() == id) {
                return true;
            }
        }
        return false;
    }
    //functie care returneaza commit-ul cu id-ul "id" din lista de commit-uri
    public final Commit getCommitWithId(final int id) {
        for (int i = commits.size() - 1; i >= 0; i--) {
            if (commits.get(i).getId() == id) {
                return commits.get(i);
            }
        }
        return null;
    }
    //functie care returneaza lista de commit-uri ce trebuie sterse cand se da checkout
    //se parcurg commit-urile de la final pana la commit-ul care are id-ul specificat
    //de paramentrul lui checkout
    public final LinkedList<Commit> getCommitsForRemove(final int id) {
        LinkedList<Commit> c = new LinkedList<Commit>();
        for (int i = commits.size() - 1; i >= 0; i--) {
            if (commits.get(i).getId() != id) {
                c.add(commits.get(i));
            }
            if (commits.get(i).getId() == id) {
                break;
            }
        }
        return c;
    }
    //functie care sterge commit-urile din lista data ca paramentru
    public final void removeCommits(final LinkedList<Commit> c) {
        for (int i = 0; i < c.size(); i++) {
            commits.remove(c.get(i));
        }
    }
}
