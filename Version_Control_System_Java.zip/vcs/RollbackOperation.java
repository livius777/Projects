package vcs;

import java.util.ArrayList;

import utils.ErrorCodeManager;
import utils.OperationType;
//clasa pentru operatia vcs rollback
public class RollbackOperation extends VcsOperation {
    public RollbackOperation(final OperationType type, final ArrayList<String> operationArgs) {
        super(type, operationArgs);
    }
    public final int execute(final Vcs vcs) {
        //luam brach-ul curent si golim stagedChanges
        //starea curenta din vcs va fi starea salvata de ultimul commit al branch-ului curent
        Branch currentBranch = vcs.getCurrentBranch();
        currentBranch.clearStagedChanges();
        vcs.modifyActiveShapshot(currentBranch.getCurrentState());
        return ErrorCodeManager.OK;
    }
}
