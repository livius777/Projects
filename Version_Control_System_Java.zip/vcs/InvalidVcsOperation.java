package vcs;

import java.util.ArrayList;

import utils.ErrorCodeManager;
import utils.OperationType;
//clasa pentru o operatie vcs invalida
public class InvalidVcsOperation extends VcsOperation {
    public InvalidVcsOperation(final OperationType type, final ArrayList<String> operationArgs) {
        super(type, operationArgs);
    }
    public final int execute(final Vcs vcs) {
        return ErrorCodeManager.VCS_BAD_CMD_CODE;
    }
}
