package vcs;

import java.util.ArrayList;

import utils.ErrorCodeManager;
import utils.OperationType;
//comanda pentru operatia de vcs commit
public class CommitOperation extends VcsOperation {
    public CommitOperation(final OperationType type, final ArrayList<String> operationArgs) {
        super(type, operationArgs);
    }
    public final int execute(final Vcs vcs) {
        Branch currentBranch = vcs.getCurrentBranch();
        //nu dam commit daca nu avem nimic in stagedChanges
        if (currentBranch.getStagedChanges().size() == 0) {
            return ErrorCodeManager.VCS_BAD_CMD_CODE;
        }
        //adaugam un nou commit in branch-ul curent
        currentBranch.addCommit(new Commit(operationArgs.get(operationArgs.size() - 1),
                vcs.getActiveShapshot()));
        return ErrorCodeManager.OK;
    }
}
