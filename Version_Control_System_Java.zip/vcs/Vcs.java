package vcs;

import filesystem.FileSystemOperation;
import filesystem.FileSystemSnapshot;
import utils.OutputWriter;
import utils.Visitor;
import java.util.LinkedList;
//am adaugat in clasa vcs o lista de branch-uri si branch-ul curent
public final class Vcs implements Visitor {
    private final OutputWriter outputWriter;
    private FileSystemSnapshot activeSnapshot;
    private Branch currentBranch;
    private LinkedList<Branch> branches;

    /**
     * Vcs constructor.
     *
     * @param outputWriter the output writer
     */
    public Vcs(final OutputWriter outputWriter) {
        this.outputWriter = outputWriter;
    }

    /**
     * Does initialisations.
     */
    public void init() {
        this.activeSnapshot = new FileSystemSnapshot(outputWriter);
      //TODO other initialisations
        //initializarea listei de branch-uri
        branches = new LinkedList<Branch>();
        //cream un nou branch cu numele master; el este branch curent
        currentBranch = new Branch("master");
        //adaugam primul commit in branch-ul master
        currentBranch.addCommit(new Commit("First commit", activeSnapshot));
        branches.add(currentBranch);
    }

    /**
     * Visits a file system operation.
     *
     * @param fileSystemOperation the file system operation
     * @return the return code
     */
    public int visit(final FileSystemOperation fileSystemOperation) {
        return fileSystemOperation.execute(this.activeSnapshot);
    }

    /**
     * Visits a vcs operation.
     *
     * @param vcsOperation the vcs operation
     * @return return code
     */
    @Override
    public int visit(final VcsOperation vcsOperation) {
        //TODO
        return vcsOperation.execute(this);
    }
    //getter branch curent
    public Branch getCurrentBranch() {
        return currentBranch;
    }
    //getter OutputWriter
    public OutputWriter getOutputWriter() {
        return outputWriter;
    }
    //functie ce verifica existenta unui branch in lista de branch-uri
    public boolean checkForBranch(final String branchName) {
        for (int i = 0; i < branches.size(); i++) {
            if (branches.get(i).getName().equals(branchName)) {
                return true;
            }
        }
        return false;
    }
    //functie care returneaza branch-ul cu numele dat de branchName din lista
    //de branch-uri
    public Branch getSearchedBranch(final String branchName) {
        for (int i = 0; i < branches.size(); i++) {
            if (branches.get(i).getName().equals(branchName)) {
                return branches.get(i);
            }
        }
        return null;
    }
    //adaugare branch in lista de branch-uri
    public void addbranch(final Branch branch) {
        branches.add(branch);
    }
    //getter activeSnapshot
    public FileSystemSnapshot getActiveShapshot() {
        return activeSnapshot;
    }
    //setter currentBranch
    public void modifyCurrentBranch(final Branch branch) {
        currentBranch = branch;
    }
    //setter activeSnapshot
    public void modifyActiveShapshot(final FileSystemSnapshot fileSystemSnapshot) {
        activeSnapshot = fileSystemSnapshot;
    }
    //TODO methods through which vcs operations interact with this
}
