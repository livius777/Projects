package vcs;

import java.util.ArrayList;
import java.util.LinkedList;
import utils.ErrorCodeManager;
import utils.OperationType;
import utils.OutputWriter;
//clasa pentru operatia vcs log
public class LogOperation extends VcsOperation {
    public LogOperation(final OperationType type, final ArrayList<String> operationArgs) {
        super(type, operationArgs);
    }
    public final int execute(final Vcs vcs) {
        //branch-ul curent
        Branch currentBranch = vcs.getCurrentBranch();
        //commit-urile branch-ului curent
        LinkedList<Commit> c = currentBranch.getCommits();
        OutputWriter outputWriter = vcs.getOutputWriter();
        //afisare id si nume commit-uri
        for (int i = 0; i < c.size(); i++) {
            outputWriter.write("Commit id: " + c.get(i).getId() + "\n");
            outputWriter.write("Message: " + c.get(i).getName() + "\n");
            if (i != c.size() - 1) {
                outputWriter.write("\n");
            }
        }
        return ErrorCodeManager.OK;
    }
}
