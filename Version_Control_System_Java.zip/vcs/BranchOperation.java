package vcs;

import java.util.ArrayList;
import utils.ErrorCodeManager;
import utils.OperationType;
//clasa pentru operatia vcs branch
public class BranchOperation extends VcsOperation {
    public BranchOperation(final OperationType type, final ArrayList<String> operationArgs) {
        super(type, operationArgs);
    }
    public final int execute(final Vcs vcs) {
        //numarul de parametri trebuie sa fie 1
        if (operationArgs.size() != 1) {
            return ErrorCodeManager.VCS_BAD_CMD_CODE;
        }
        //branch-ul curent
        Branch currentBranch = vcs.getCurrentBranch();
        //cream un nou branch cu numele specificat de comanda
        Branch branch = new Branch(operationArgs.get(0));
        //am presupus ca se da automat un commit pe noul branch cu numele ultimului commit
        //de pe branch-ul curent
        String s = currentBranch.getCommits().getLast().getName();
        branch.addCommit(new Commit(s, currentBranch.getCurrentState()));
                if (vcs.checkForBranch(operationArgs.get(0))) {
            return ErrorCodeManager.VCS_BAD_CMD_CODE;
        }
        vcs.addbranch(branch);
        return ErrorCodeManager.OK;
    }
}
