package vcs;

import filesystem.FileSystemSnapshot;
import utils.IDGenerator;
//clasa Commit contine nume, id si starea sistemului salvata la un moment dat
public class Commit {
    private String name;
    private int id;
    private FileSystemSnapshot curentSystemState;
    public Commit(final String name, final FileSystemSnapshot curentSystemState) {
        this.name = name;
        id = IDGenerator.generateCommitID();
        this.curentSystemState = curentSystemState.cloneFileSystem();
    }
    //getter name
    public final String getName() {
        return name;
    }
    //getter id
    public final int getId() {
        return id;
    }
    //getter currentSystemState
    public final FileSystemSnapshot getFileSystemSnapshot() {
        return curentSystemState;
    }
}
