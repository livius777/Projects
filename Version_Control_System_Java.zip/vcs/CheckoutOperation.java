package vcs;

import java.util.ArrayList;
import java.util.LinkedList;
import utils.ErrorCodeManager;
import utils.OperationType;
//clasa pentru operatia vcs checkout
public class CheckoutOperation extends VcsOperation {
    public CheckoutOperation(final OperationType type, final ArrayList<String> operationArgs) {
        super(type, operationArgs);
    }
    public final int execute(final Vcs vcs) {
        //daca stagedChanges nu este gol, atunci nu avem o comanda valida
        if (vcs.getCurrentBranch().getStagedChanges().size() > 0) {
            return ErrorCodeManager.VCS_STAGED_OP_CODE;
        }
        //un argument => schimbam branch-ul
        if (operationArgs.size() == 1) {
            if (!vcs.checkForBranch(operationArgs.get(0))) {
                return ErrorCodeManager.VCS_BAD_CMD_CODE;
            }
            //branchul cu numele specificat
            Branch branch = vcs.getSearchedBranch(operationArgs.get(0));
            vcs.modifyCurrentBranch(branch);
            //starea curenta din vcs va fi starea ultimului commit din nou-ul string
            vcs.modifyActiveShapshot(branch.getCurrentState());
            return ErrorCodeManager.OK;
        }
        //avem doua argumente, primul fiind "-c"
        if (operationArgs.size() == 2) {
            int id = Integer.parseInt(operationArgs.get(1));
            if (!vcs.getCurrentBranch().hasCommitWithId(id)) {
                return ErrorCodeManager.VCS_BAD_PATH_CODE;
            }
            //commit-urile ce trebuiesc sterse
            LinkedList<Commit> c = vcs.getCurrentBranch().getCommitsForRemove(id);
            //stergem committ-urile din branch-ul curent
            vcs.getCurrentBranch().removeCommits(c);
            //starea curenta din vcs va fi starea salvata de commit-ul cu id-ul specificat
            //de al doilea argument al comenzii (cel la care ne intoarcem)
            vcs.modifyActiveShapshot(vcs.getCurrentBranch().getCommitWithId(id)
                    .getFileSystemSnapshot());
            return ErrorCodeManager.OK;
        }
        return ErrorCodeManager.VCS_BAD_CMD_CODE;
    }
}
