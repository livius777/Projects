package vcs;

import java.util.ArrayList;

import utils.ErrorCodeManager;
import utils.OperationType;

import utils.OutputWriter;
//clasa pentru operatia vcs status
public class StatusOperation extends VcsOperation {
    public StatusOperation(final OperationType type, final ArrayList<String> operationArgs) {
       super(type, operationArgs);
    }
    public final int execute(final Vcs vcs) {
        //afisam numele branch-ului si fiecare element String din lista de stagedChanges
        OutputWriter outputWriter = vcs.getOutputWriter();
        outputWriter.write("On branch: " + vcs.getCurrentBranch().getName() + "\n");
        outputWriter.write("Staged changes:" + "\n");
        for (int i = 0; i < vcs.getCurrentBranch().getStagedChanges().size(); i++) {
            outputWriter.write(vcs.getCurrentBranch().getStagedChanges().get(i) + "\n");
        }
        return ErrorCodeManager.OK;
    }
}
