{-# OPTIONS_GHC -Wall #-}
{-# LANGUAGE MultiParamTypeClasses #-}

module Search where

import ProblemState

import qualified Data.Set as S
import qualified Data.Maybe as M
{-
    *** TODO ***

    Tipul unei nod utilizat în procesul de căutare. Recomandăm reținerea unor
    informații legate de:

    * stare;
    * acțiunea care a condus la această stare;
    * nodul părinte, prin explorarea căruia a fost obținut nodul curent;
    * adâncime
    * copiii, ce vor desemna stările învecinate
-}

data Node s a = MkNod { state::s, action:: Maybe a, parent:: Maybe (Node s a), deep::Int, kids::[(a,s)] }

{-
    *** TODO ***

    Întoarce starea stocată într-un nod.
-}

nodeState :: Node s a -> s
nodeState  (MkNod state _ _ _ _)= state

{-
    *** TODO ***

    Generarea întregului spațiu al stărilor 
    Primește starea inițială și creează nodul corespunzător acestei stări, 
    având drept copii nodurile succesorilor stării curente.
-}

createStateSpace :: (ProblemState s a) => s -> Node s a
createStateSpace st = MkNod st Nothing Nothing 0 (successors st)

getNode st act ad par = MkNod st (Just act) (Just par) ad (successors st)
getNextNodes succ ad par = map (\x -> getNode (snd x) (fst x) ad par) succ  

{-
    *** TODO PENTRU BONUS ***

    Ordonează întreg spațiul stărilor după euristica din ProblemState. 
    Puteți folosi `sortBy` din Data.List.
-}

orderStateSpace :: (ProblemState s a) => Node s a -> Node s a
orderStateSpace = undefined


{-
    *** TODO ***

    Întoarce lista nodurilor rezultate prin parcurgerea limitată în adâncime
    a spațiului stărilor, pornind de la nodul dat ca parametru.

    Pentru reținerea stărilor vizitate, recomandăm Data.Set. Constrângerea
    `Ord s` permite utilizarea tipului `Set`.
-}
takeunvisited :: (ProblemState s a, Ord s) => S.Set s -> [Node s a] -> Int -> [Node s a]
takeunvisited visited succ ad = filter (\x -> (S.notMember (state x) visited) && (deep x <= ad)) succ 
dfs :: (ProblemState s a, Ord s) => Node s a -> S.Set s -> Int -> Int -> [Node s a]
dfs node visited ad currdepp
    | null posbl  && (S.notMember (state node) visited) = [node]
    | null posbl && (S.member (state node) visited) = [] 
    | length posbl == 1 = [node] ++ part1
    | length posbl == 2 = [node] ++ part1 ++ part2
    | length posbl == 3 = [node] ++ part1 ++ part2 ++ part3
    | otherwise = [node] ++ part1 ++ part2 ++ part3 ++ part4
    where
        posbl = takeunvisited (S.insert (state node) visited) (getNextNodes (successors $ state node) (currdepp + 1) node) ad
        part1 = dfs (head posbl) (S.insert (state node) visited) ad (currdepp + 1)
        part2 = dfs (head (tail posbl)) (S.union (S.insert (state node) visited) (S.fromList (map (\x -> state x) part1))) ad (currdepp + 1)
        part3 = dfs (head (tail (tail posbl))) (S.union (S.union (S.insert (state node) visited) (S.fromList (map (\x -> state x) part1))) (S.fromList (map (\x -> state x) part2))) ad (currdepp + 1)
        part4 = dfs (head (tail (tail (tail posbl)))) (S.union (S.union (S.union (S.insert (state node) visited) (S.fromList (map (\x -> state x) part1))) (S.fromList (map (\x -> state x) part2))) (S.fromList (map (\x -> state x) part3))) ad (currdepp + 1)

limitedDfs :: (ProblemState s a, Ord s)
           => Node s a    -- Nodul stării inițiale
           -> Int         -- Adâncimea maximă de explorare
           -> [Node s a]  -- Lista de noduri
limitedDfs node admax = dfs node (S.empty) admax 0

{-
    *** TODO ***

    Explorează în adâncime spațiul stărilor, utilizând adâncire iterativă,
    pentru determinarea primei stări finale întâlnite.

    Întoarce o perche între nodul cu prima stare finală întâlnită și numărul
    de stări nefinale vizitate până în acel moment.
-}
getLen :: (ProblemState s a, Ord s) => s-> [s] -> Int -> Int
getLen x l acc
    | l == [] = 0
    | x == head l = acc
    | otherwise = getLen x (tail l) (1 + acc) 
checkgoal :: (ProblemState s a, Ord s) => Node s a -> [Int] -> Int -> ((Node s a, Int), Int)
checkgoal node manydeeps howmany = if length posblGolas > 0 then (((head posblGolas), howmany + (getLen (state (head posblGolas)) (map state (limitedDfs node (head manydeeps))) 0)), (head manydeeps)) else (checkgoal node (tail manydeeps) (howmany + size))
    where
        posblGolas = filter (\x -> isGoal (state x)) (limitedDfs node (head manydeeps))
        size = length $ limitedDfs node (head manydeeps)

iterativeDeepening :: (ProblemState s a, Ord s)
    => Node s a         -- Nodul stării inițiale
    -> (Node s a, Int)  -- (Nod cu prima stare finală,
                        --  număr de stări nefinale vizitate)
iterativeDeepening node = fst $ checkgoal node [0..200] 0

{-
    *** TODO ***

    Pornind de la un nod, reface calea către nodul inițial, urmând legăturile
    către părinți.

    Întoarce o listă de perechi (acțiune, stare), care se încheie în starea
    finală, dar care EXCLUDE starea inițială.
-}

extractPath :: Node s a -> [(a, s)]
extractPath node
    | M.isNothing (parent node) = []
    | otherwise = extractPath (M.fromJust $ parent node) ++ [(M.fromJust $ action node, state node)]

{-
    *** TODO ***

    Pornind de la o stare inițială, se folosește de iterativeDeepening pentru 
    a găsi prima stare finală și reface calea către nodul inițial folosind 
    extractPath. 
  
    Întoarce o listă de perechi (acțiune, stare), care se încheie în starea
    finală, dar care EXCLUDE starea inițială.
-}


solve :: (ProblemState s a, Ord s)
      => s          -- Starea inițială de la care se pornește 
      -> Bool       -- Dacă să folosească sau nu euristica dată 
      -> [(a, s)]   -- Lista perechilor
solve s heur
    | heur == False = extractPath $ fst (iterativeDeepening $ createStateSpace s)
    | otherwise = []          

{-
    Poate fi utilizată pentru afișarea fiecărui element al unei liste
    pe o linie separată.
-}

printSpacedList :: Show a => [a] -> IO ()
printSpacedList = mapM_ (\a -> print a >> putStrLn (replicate 20 '*'))