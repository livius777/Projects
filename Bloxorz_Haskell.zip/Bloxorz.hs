{-# OPTIONS_GHC -Wall #-}
{-# LANGUAGE EmptyDataDecls, MultiParamTypeClasses,
             TypeSynonymInstances, FlexibleInstances,
             InstanceSigs #-}


module Bloxorz where

import ProblemState

import qualified Data.Array as A

{-
    Caracterele ce vor fi printate pentru fiecare tip de obiect din joc 
    Puteți înlocui aceste caractere cu orice, în afară de '\n'.
-}

hardTile :: Char
hardTile = '▒'

softTile :: Char
softTile = '='

block :: Char
block = '▓'

switch :: Char
switch = '±'

emptySpace :: Char
emptySpace = ' '

winningTile :: Char
winningTile = '*'

{-
    Sinonim de tip de date pentru reprezetarea unei perechi (int, int)
    care va reține coordonatele de pe tabla jocului
-}

type Position = (Int, Int)

{-
    Direcțiile în care se poate mișcă blocul de pe tablă
-}

data Directions = North | South | West | East
    deriving (Show, Eq, Ord)

{-
    *** TODO ***

    Tip de date care va reprezenta plăcile care alcătuiesc harta și switch-urile
-}

data Cell = GameCell { cel :: Char, pos :: (Int, Int) } deriving (Eq, Ord)

instance Show Cell where
    show (GameCell cel _) =  [cel]

{-
    *** TODO ***

    Tip de date pentru reprezentarea nivelului curent
-}

data Level = Lvl { cells :: A.Array (Int, Int) Cell, size :: (Int, Int), blockpos :: (Int, Int), s:: String, swiPos :: [((Int, Int),[(Int, Int)])], blockpos2 :: (Int, Int)}
    deriving (Eq, Ord)


{-
    *** Opțional *** 
  
    Dacă aveți nevoie de o funcționalitate particulară, 
    instantiati explicit clasele Eq și Ord pentru Level. 
    În cazul acesta, eliminați deriving (Eq, Ord) din Level. 
-}

-- instance Eq Level where
--     (==) = undefined

-- instance Ord Level where
--     compare = undefined

{-
    *** TODO ***

    Instantiati Level pe Show. 

    Atenție! String-ul returnat va fi urmat și precedat de un rând nou. 
    În cazul în care jocul este câștigat, la sfârșitul stringului se va mai
    concatena mesajul "Congrats! You won!\n". 
    În cazul în care jocul este pierdut, se va mai concatena "Game Over\n". 
-}
dif tup1 tup2 = (fst tup1 - fst tup2, snd tup1 - snd tup2)
getrow i (Lvl cells size bpos s swipos bpos2)
    | (dif bpos bpos2 == (0,0)) && i /= fst bpos = concat $ [show (cells A.! (i, y)) | y <- [0..snd size]] ++ ["\n"]
    {-| i /= fst bpos = concat $ [show (cells A.! (i, y)) | y <- [0..snd size]] ++ ["\n"]
    | otherwise = concat $ [show (cells A.! (i, y)) | y <- [0..(snd bpos - 1)]] ++ [[block]] ++ [show (cells A.! (i, y)) | y <- [(1 + snd bpos)..snd size]] ++ ["\n"]
    -}
    | (dif bpos bpos2 == (0,0)) && i == fst bpos = concat $ [show (cells A.! (i, y)) | y <- [0..(snd bpos - 1)]] ++ [[block]] ++ [show (cells A.! (i, y)) | y <- [(1 + snd bpos)..snd size]] ++ ["\n"]
    | (fst (dif bpos bpos2) == 0) && i /= fst bpos = concat $ [show (cells A.! (i, y)) | y <- [0..snd size]] ++ ["\n"]
    | (fst (dif bpos bpos2) == 0) && i == fst bpos = concat $ [show (cells A.! (i, y)) | y <- [0..(min (snd bpos) (snd bpos2) - 1)]] ++ [[block]] ++ [[block]] ++ [show (cells A.! (i, y)) | y <- [(1 + max (snd bpos) (snd bpos2))..snd size]] ++ ["\n"]
    | (snd (dif bpos bpos2) == 0) && i == fst bpos = concat $ [show (cells A.! (i, y)) | y <- [0..(snd bpos - 1)]] ++ [[block]] ++ [show (cells A.! (i, y)) | y <- [(1 + snd bpos)..snd size]] ++ ["\n"]
    | (snd (dif bpos bpos2) == 0) && i == fst bpos2 = concat $ [show (cells A.! (i, y)) | y <- [0..(snd bpos2 - 1)]] ++ [[block]] ++ [show (cells A.! (i, y)) | y <- [(1 + snd bpos2)..snd size]] ++ ["\n"]
    |otherwise = concat $ [show (cells A.! (i, y)) | y <- [0..snd size]] ++ ["\n"]

instance Show Level where
    show (Lvl cells size bpos s swipos bpos2) = harta
        where
            harta = concat $  ["\n"] ++ [getrow i (Lvl cells size bpos s swipos bpos2) | i <- [0.. fst size]] ++ [s]

{-
    *** TODO ***

    Primește coordonatele colțului din dreapta jos a hârtii și poziția inițială a blocului.
    Întoarce un obiect de tip Level gol.
    Implicit, colțul din stânga sus este (0, 0).
-}

emptyLevel :: Position -> Position -> Level
emptyLevel dim bpos = Lvl a dim bpos "" [] bpos
    where
        m = fst dim
        n = snd dim
        a = A.array ((0,0), (m, n)) ([((i,j), GameCell emptySpace (i,j)) | i <- [0..m], j <- [0..n]])
        
        

{-
    *** TODO ***

    Adaugă o celulă de tip Tile în nivelul curent.
    Parametrul char descrie tipul de tile adăugat: 
        'H' pentru tile hard 
        'S' pentru tile soft 
        'W' pentru winning tile 
-}

addTile :: Char -> Position -> Level -> Level
addTile tip pos (Lvl cells size blockpos s swipos bpos2)
    | tip == 'H' = Lvl (cells A.// [((fst pos, snd pos),  GameCell hardTile pos)]) size blockpos s swipos bpos2
    | tip == 'S' = Lvl (cells A.// [((fst pos, snd pos), GameCell softTile pos)]) size blockpos s swipos bpos2
    | tip == 'W' = Lvl (cells A.// [((fst pos, snd pos), GameCell winningTile pos)]) size blockpos s swipos bpos2

{-
    *** TODO ***

    Adaugă o celulă de tip Swtich în nivelul curent.
    Va primi poziția acestuia și o listă de Position
    ce vor desemna pozițiile în care vor apărea sau 
    dispărea Hard Cells în momentul activării/dezactivării
    switch-ului.
-}

addSwitch :: Position -> [Position] -> Level -> Level
addSwitch pos lpos (Lvl cells dim bpos s swipos bpos2) = Lvl (cells A.// [((fst pos, snd pos),  GameCell switch pos)]) dim bpos s ((pos, lpos):swipos) bpos2

{-
    === MOVEMENT ===
-}

{-
    *** TODO ***

    Activate va verifica dacă mutarea blocului va activa o mecanică specifică. 
    În funcție de mecanica activată, vor avea loc modificări pe hartă. 
-}
getPositions p l = snd $ head $ filter (\elem -> if fst elem == p then True else False) l
activateswitches cells l
    | l == [] = cells
    | cel (cells A.! (fst $ head l, snd $ head l)) == emptySpace = activateswitches (cells A.// [((fst $ head l, snd $ head l),  GameCell hardTile (i,j))]) (tail l)
    |  cel (cells A.! (fst $ head l, snd $ head l)) == hardTile = activateswitches (cells A.// [((fst $ head l, snd $ head l),  GameCell emptySpace (i, j))]) (tail l)
    where
    (i,j) = pos $ cells A.! (fst $ head l, snd $ head l)
activate :: Cell -> Level -> Level
activate (GameCell cel pos) l@(Lvl cells size bpos s swipos bpos2)
    | cel == hardTile = l
    | cel == softTile && ((dif bpos bpos2) == (0,0)) = Lvl cells size bpos "Game Over\n" swipos bpos2
    | cel == emptySpace = Lvl cells size bpos "Game Over\n" swipos bpos2
    | cel == winningTile && ((dif bpos bpos2) == (0,0)) = Lvl cells size bpos "Congrats! You won!\n" swipos bpos2
    | cel == switch = Lvl (activateswitches cells (getPositions pos swipos)) size bpos s swipos bpos2
    | otherwise = l
{-
    *** TODO ***

    Mișcarea blocului în una din cele 4 direcții 
    Hint: Dacă jocul este deja câștigat sau pierdut, puteți lăsa nivelul neschimbat.
-}

move :: Directions -> Level -> Level
move dir l@(Lvl cells size bpos s swipos bpos2)
    | s /= "" = l
    | (dif bpos bpos2) == (0,0) && dir == North = activate (cells A.! ((fst bpos - 2), snd bpos)) (activate (cells A.! ((fst bpos - 1), snd bpos)) (Lvl cells size ((fst bpos - 1), snd bpos) s swipos ((fst bpos2 - 2, snd bpos2))))
    | (dif bpos bpos2) == (0,0) && dir == South = activate (cells A.! ((fst bpos + 2), snd bpos)) (activate (cells A.! ((fst bpos + 1), snd bpos)) (Lvl cells size ((fst bpos + 2), snd bpos) s swipos ((fst bpos2 + 1, snd bpos2))))
    | (dif bpos bpos2) == (0,0) && dir == West = activate (cells A.! (fst bpos, (snd bpos - 2))) (activate (cells A.! (fst bpos, (snd bpos - 1))) (Lvl cells size (fst bpos, (snd bpos - 1)) s swipos (fst bpos2, (snd bpos2 - 2))))
    | (dif bpos bpos2) == (0,0) && dir == East = activate (cells A.! (fst bpos, (snd bpos + 2))) (activate (cells A.! (fst bpos, (snd bpos + 1))) (Lvl cells size (fst bpos, (snd bpos + 2)) s swipos (fst bpos2, (snd bpos2 + 1))))   
    | fst (dif bpos bpos2) == 0 && dir == North = activate (cells A.! ((fst bpos - 1), snd bpos)) (activate (cells A.! ((fst bpos2 - 1), snd bpos2)) (Lvl cells size ((fst bpos - 1), snd bpos) s swipos ((fst bpos2 - 1), snd bpos2)))
    | fst (dif bpos bpos2) == 0 && dir == South = activate (cells A.! ((fst bpos + 1), snd bpos)) (activate (cells A.! ((fst bpos2 + 1), snd bpos2)) (Lvl cells size ((fst bpos + 1), snd bpos) s swipos ((fst bpos2 + 1), snd bpos2)))
    | fst (dif bpos bpos2) == 0 && dir == West = activate (cells A.! (fst bpos, (snd bpos - 2)))  (Lvl cells size (fst bpos, (snd bpos - 2)) s swipos ((fst bpos, (snd bpos - 2))))
    | fst (dif bpos bpos2) == 0 && dir == East = activate (cells A.! (fst bpos, (snd bpos + 1)))  (Lvl cells size (fst bpos, (snd bpos + 1)) s swipos ((fst bpos, (snd bpos + 1))))
    | snd (dif bpos bpos2) == 0 && dir == North = activate (cells A.! ((fst bpos - 2), snd bpos))  (Lvl cells size ((fst bpos - 2), snd bpos) s swipos ((fst bpos - 2), snd bpos))
    | snd (dif bpos bpos2) == 0 && dir == South = activate (cells A.! ((fst bpos + 1), snd bpos))  (Lvl cells size ((fst bpos + 1), snd bpos) s swipos ((fst bpos + 1), snd bpos))
    | snd (dif bpos bpos2) == 0 && dir == West = activate (cells A.! (fst bpos, (snd bpos - 1))) (activate (cells A.! (fst bpos2, (snd bpos2 - 1))) (Lvl cells size (fst bpos, (snd bpos - 1)) s swipos (fst bpos2, (snd bpos2 - 1))))
    | snd (dif bpos bpos2) == 0 && dir == East = activate (cells A.! (fst bpos, (snd bpos + 1))) (activate (cells A.! (fst bpos2, (snd bpos2 + 1))) (Lvl cells size (fst bpos, (snd bpos + 1)) s swipos (fst bpos2, (snd bpos2 + 1))))
    
{-
    *** TODO ***

    Va returna True dacă jocul nu este nici câștigat, nici pierdut.
    Este folosită în cadrul Interactive.
-}

continueGame :: Level -> Bool
continueGame (Lvl cells size bpos s swipos bpos2) = if s == "" then True else False

{-
    *** TODO ***

    Instanțiați clasa `ProblemState` pentru jocul nostru. 
  
    Hint: Un level câștigat nu are succesori! 
    De asemenea, puteți ignora succesorii care 
    duc la pierderea unui level.
-}

getAsuccesor dir l@(Lvl cells size bpos str swipos bpos2) = if (s (move dir l) == "Game Over\n") then [] else [(dir, (move dir l))]

instance ProblemState Level Directions where
    successors l@(Lvl cells size bpos s swipos bpos2)
        | s == "Congrats! You won!\n" = []
        | otherwise = (getAsuccesor North l) ++ (getAsuccesor South l) ++ (getAsuccesor West l) ++ (getAsuccesor East l)     

    isGoal l@(Lvl cells size bpos s swipos bpos2) = if s == "Congrats! You won!\n" then True else False

    -- Doar petru BONUS
    -- heuristic = undefined
