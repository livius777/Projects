// Copyright [2018] Liviu Chirimbu
#ifndef HASHTABLE_H_
#define HASHTABLE_H_
#include <algorithm>
#include <iterator>
#include <list>

// pereche cheie, valoare
template <typename Tkey, typename Tvalue> struct elem_info {
	Tkey key;
	Tvalue value;
};

template <typename Tkey, typename Tvalue> class Hashtable {
	private:
	std::list<struct elem_info<Tkey, Tvalue> > * H;  //  pointer la buchete
	int HMAX;  //  numarul de buchete
	unsigned int (*hash)(Tkey);  //  pointer la functia de hash
	unsigned int size;  //  numarul de elemente in hastable

	public:
	// Constructor
	// h pointer la functia de hash
	// alocam un vector de liste
	Hashtable(int hmax, unsigned int (*h)(Tkey)) {
		HMAX = hmax;
		hash = h;
		H = new std::list <struct elem_info<Tkey, Tvalue> > [hmax];
	}
	// Destructor
	// Eliberam memoria
	~Hashtable() {
		delete [] H;
	}
	// Adaugam o pereche (cheie, valoare) in hastable
	// Folosind functia de hash aflam pe ce buchet se insereaza perechea
	// Daca gasim cheia, doar modificam valoarea, daca nu, adaugam perechea la
	// finalul listeti
	void put(Tkey key, Tvalue value) {
		int index = hash(key) % HMAX;
		typename std::list<struct elem_info<Tkey, Tvalue> > ::iterator it;
		for (it = H[index].begin(); it != H[index].end(); ++it) {
			if (it->key == key) {
				it->value = value;
				return;
			}
		}
		// nu am gasit cheia, deci o punem la capatul bucketului
		struct elem_info<Tkey, Tvalue> info;
		info.key = key;
		info.value = value;
		H[index].push_back(info);
 	}
 	// stergem o pereche cheie, valoare
 	// pasii sunt asemanatori cu functia put, doar ca atunci cand gasim
 	// perechea, o stergem
	void remove(Tkey key) {
		int index = hash(key) % HMAX;
		typename std::list<struct elem_info<Tkey, Tvalue> >::iterator it;
		for (it = H[index].begin(); it != H[index].end(); ++it) {
			if (it->key == key) {
				it = H[index].erase(it);
			}
		}
	}
	// functie care returneaza valoarea asocitata unei chei data ca parametru
	// este asemanatoare cu functia put, doar ca atunci cand gasim cheia
	// returnam valoarea asociata
	Tvalue get(Tkey key) {
		int index = hash(key) % HMAX;
		typename std::list<struct elem_info<Tkey, Tvalue> >::iterator it;
		for (it = H[index].begin(); it != H[index].end(); it++) {
			if (it->key == key) {
				return it->value;
			}
		}
		return Tvalue();
	}
	// functie care verifica daca o cheie a fost adaugata in buchet sau nu
	// este asemanatoare cu functia put
	bool has_key(Tkey key) {
		int index = hash(key) % HMAX;
		typename std::list<struct elem_info<Tkey, Tvalue> >::iterator it;
		for (it = H[index].begin(); it != H[index].end(); ++it) {
			if (it->key == key) {
				return true;
			}
		}
		return false;
	}

	int get_size() {
		return size;
	}

	int get_capacity() {
		return HMAX;
	}
};

#endif  //  HASHTABLE_H_
