// Copyright [2018] Liviu Chirimbu
#ifndef LISTGRAPH_GENERIC1_H_
#define LISTGRAPH_GENERIC1_H_

#include <vector>
// Structura Node contine campul neighbors in care se retine indexul vecinilor unui nod
// si informatia dintr-un nod
template <typename T> struct Node {
    T data;
    std::vector<int> neighbors;
};
// nodes este un vector de Node
// nodesT este un vector de Node, dar este folosit pentru graful transpus
// degree este un vector de int ce retine gradul interior al unui nod
template <typename T> class ListGraph {
private:
    std::vector<Node<T>> nodes;
    std::vector<Node<T>> nodesT;
    std::vector<int> degree;
    int size;

public:
    // Constructor
    ListGraph(int size) {
       this->size = size;
	   nodes.resize(size);
       nodesT.resize(size);
       degree.resize(size);
	   for (int i = 0; i < size; i++) {
		  nodes[i].neighbors.resize(0);
	   }
       for (int i = 0; i < size; i++) {
          nodesT[i].neighbors.resize(0);
       }

    }

    // Destructor
    ~ListGraph() {}
    // Setam informatia in nodul k
    void setInfo(int k, T data) {
        nodes[k].data = data;
        nodesT[k].data = data;
    }
    // luam informatia din nodul cu indexul k
    T getInfo(int k) {
        return nodes[k].data;
    }
    // Functie care adauga muchia [src, dst] in graf si muchia [dst, src] in
    // graful transpus
    // se mareste cu 1 gradul interior al lui dst
    void addEdge(int src, int dst) {
        nodes[src].neighbors.push_back(dst);
        nodesT[dst].neighbors.push_back(src);
        degree[dst]++;
    }
    // Functie care verifica daca exista muchia [src, dst] in graf, parcurgand
    // lista de vecini a lui src
    bool hasEdge(int src, int dst) {
        for (unsigned int i = 0; i < nodes[src].neighbors.size(); i++) {
		    if (nodes[src].neighbors[i] == dst) {
			    return true;
		    }
	    }
        return false;
    }
    // functie care returneaza vecinii uni nod
    std::vector<int> getNeighbors(int node) {
       	return nodes[node].neighbors;
    }
    // functie care returneaza vecinii unui nod, insa din graful transpus
    std::vector<int> getNeighborsT(int node) {
        return nodesT[node].neighbors;
    }
    // functie care returneaza dimensiunea grafului
    int getSize() {
        return size;
    }
    // functie care returneaza vectorul de grade interioare
    std::vector <int> getDegree() {
        return degree;
    }
};

#endif // LISTGRAPH_GENERIC1_H_
