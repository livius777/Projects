// Copyright [2018] Liviu Chirimbu
#ifndef HASH_FUNCTIONS_H_
#define HASH_FUNCTIONS_H_

#define INT_HASH	70001

#include <string.h>
#include <string>

// functie de hash pentru int-uri
unsigned int hashingFunction(int nr){
    return nr % INT_HASH;
}

// functie de hash pentru string-uri dupa modelul celei de la curs
unsigned int charHashingFunction(std::string str){
    unsigned int hash = 5381;
    for (int i = 0; i < str.length(); i++) {
    	hash = ((hash << 5) + hash) + str[i];
    }
    return hash;
}

#endif  //  HASH_FUNCTIONS_H_
