// Copyright [2018] Liviu Chirimbu
#include <iostream>
#include <fstream>
#include "hashtable.h"
#include "hash_functions.h"
#include "ListGraph_generic1.h"
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <algorithm>
using namespace std;
// structura folosita la task-ul 5
typedef struct {
	string s1, s2;
	int passagers;
}task5_t;
// functie de comparare a doua structuri de tip tas5_t
bool compare_function(task5_t A, task5_t B) {
	if (A.s1 < B.s1 ){
		return true;
	}else if (A.s1 == B.s1) {
		if (A.s2 <= B.s2) {
			return true;
		}
		else
			return false;
	}
	else
		return false;
}
// functie care realizeaza un DFS pe graf, cu retinerea unui nod intr-o stiva 
// in momentul in care acel nod nu mai are vecini sau s-au vizitat toti 
// vecinii sai
void DFS_Kosaraju(int k, int n, ListGraph<int> &a, vector <int> &visited, stack<int> &s) {
	visited[k] = 1;
	vector<int> u = a.getNeighbors(k);
	for (int i = 0; i < u.size(); i++) {
		if (!visited[u[i]]) {
			DFS_Kosaraju(u[i], n , a, visited, s);
		}
	}
	s.push(k);
}
// functie care realizeaza un DFS cu retinerea solutiei intr-un vector,
// transpus 
vector <int> DFST_Kosaraju(int k, int n, ListGraph<int> &a, vector<int> &visited) {
	std::stack<int> s; // stiva pentru parcurgerea DFS
	vector<int> vect; // vector de retinere a solutiei
	visited[k] = 1; // vizitam sursa
	vect.push_back(k); // o adaugam la solutie si in stiva
	s.push(k);
	while (!s.empty()) {
		// luam nodul din varful stivei
		int top = s.top();
		int sw = 0;
		// vectorul cu vecinii lui top
		vector <int> u = a.getNeighborsT(top);
		// daca exista vecini nevizitati, primul dintre ei este adaugat
		// in stiva
		// si in vect si este viziztat
		// daca nu exsista astfel de nod, facem pop la stiva
		for (int i = 0; i < u.size(); i++) {
			if (!visited[u[i]]) {
				sw = 1;
				visited[u[i]] = 1;
				vect.push_back(u[i]);
				s.push(u[i]);
				break;
			}
		}
		if (!sw) {
			s.pop();
		}
	}
	return vect;
}
// functie care determina componentele tare conexe folosind algoritmul lui
// Kosaraju; se realizeaza o parcurgere DFS pe toate nodurile din graf ramase
// nevizitate, iar acestea se aduaga in stiva s dupa cum este descris mai sus
// apoi nodurile se fac din nou nevizitate si folosind stiva, se realizeaza
// parcurgere DFS  pe graful transpus
// nodurile rezultate in urma unei astfel de percurgeri DFS reprezinta o
// componeneta tare conexa
vector <vector<int>> CTC(int n, ListGraph <int> &a, vector <int> &ap) {
	vector < vector<int> > ctc;
	int nrc = 0;
	stack<int> s;
	vector<int> visited(n, 0);
	for (int  i = 0; i < n; i++) {
		if (!visited[i]) {
			DFS_Kosaraju(i, n, a, visited, s);
		}
	}
	for (int i = 0; i < n; i++) {
		visited[i] = 0;
	}
	while (!s.empty()) {
		int top = s.top();
		s.pop();
		if (!visited[top]) { 
			vector <int> vect = DFST_Kosaraju(top, n, a, visited);
			if (vect.size() > 0) {
				nrc++;
				ctc.resize(nrc);
				ctc[nrc - 1] = vect;
				for (int i = 0; i < vect.size(); i++){
					ap[vect[i]] = nrc - 1;
				}
			}
		}
	}
	return ctc;
}
// functie care retuneaza orasele inaccesibile unui oras
// acesta este dat ca paramentru (int, pentru ca lucram pe graf) k
// orasele inaccesibile lui k sunt cele din componenetele tare conexe diferite
// de componenta tare conexa din care face parte k
void get_towns_task3(int k, vector <int> &ap, vector<int> &inaccesibile) {
	for (int i = 0; i < ap.size(); i++) {
		if (ap[i] != ap[k]) {
			inaccesibile.push_back(i);
		}
	}
}
// functie care realizeaza o parcurgere BFS a unui graf, determinand in stiva
// road un drum minim de la nodul i la nodul j
void BFS(int i, int j, int n, ListGraph <int> &a, stack <int> &road) {
	int inf = 2 << 20;
	// initial nodurile sunt nevizitate
	vector <int> visited(n, 0);
	// distanta dintre un nod si nodul sursa este initial infinit
	vector <int> d(n, inf);
	// coada pentru retinerea solutiei
	queue <int> q;
	// vector de parinti
	vector <int> p(n, -1);
	// vizitam sursa, o adaugam in coada
	visited[i] = 1;
	q.push(i);
	d[i] = 0;
	// cat timp stiva nu e goala
	while (!q.empty()) {
		// extragem nodul v din coada
		int v = q.front();
		q.pop();
		// luam vecinii nodului v (sortati) si pentru fiecare vecin 
		// nevizitat il adaugam
		// coada si facem operatiile necesare asupra sa(vizitare, parinti, distanta)
		vector <int> u = a.getNeighbors(v);
		sort(u.begin(), u.begin() + u.size());
		for (int k = 0; k < u.size(); k++) {
			if (!visited[u[k]]) {
				visited[u[k]] = 1;
				q.push(u[k]);
				d[u[k]] = d[v] + 1;
				p[u[k]] = v;
			}
		}
	}
	// costruim drumul de la i la j folosind stiva road si vectorul de parinti
	do {
		road.push(j);
		j = p[j];
	}while(j != -1); 
}
// parcurgere BFS asemanatoare, doar ca ne oprim atunci cand intalnim
// o benzinarie
int BFS_dist(int i, int n, ListGraph <int> &a, vector <int> &ap_benzinarii) {
	int inf = 2 << 20;
	vector <int> visited(n, 0);
	vector <int> d(n, inf);
	queue <int> q;
	vector <int> p(n, -1);
	visited[i] = 1;
	q.push(i);
	d[i] = 0;
	while (!q.empty()) {
		int v = q.front();
		q.pop();
		vector <int> u = a.getNeighbors(v);
		for (int k = 0; k < u.size(); k++) {
			if (!visited[u[k]]) {
				visited[u[k]] = 1;
				q.push(u[k]);
				d[u[k]] = d[v] + 1;
				p[u[k]] = v;
				if (ap_benzinarii[u[k]]) {
					return d[u[k]];
				}
			}
		}
	}
	return inf;
}
int main() {
	ofstream fout1("task1.out");
	ofstream fout2("task2.out");
	ofstream fout3("task3.out");
	ofstream fout4("task4.out");
	ofstream fout5("task5.out");
	int n, m, nr_b, nr_i; // n orase, m muchii, nr_i orase task 3,
	// nr_b benzinarii;
	//Cele doua table pentru asocierea int<->string, in ambele sensuri
	Hashtable <std::string, int> table_string_to_int(5000, &charHashingFunction);
	Hashtable <int, std::string> table_int_to_string(5000, &hashingFunction);
	cin >> n >> m;
	// Graf cu noduri de tip int
	ListGraph <int> a(n);
	string s1, s2;
	// Pentru fiecare oras realizam corespondenta intre string si nodul din graf
	// de tip int
	for (int i = 0; i< n; i++) {
		cin >> s1;
		table_string_to_int.put(s1, i);
		table_int_to_string.put(i, s1);
	}
	// adaugam cele m muchii in graf, folosindu-ne de primul hastable
	// pentru a realiza corespondenta string -> int
	for (int i = 0; i < m; i++) {
		cin >> s1 >> s2;
		int l = table_string_to_int.get(s1);
		int k = table_string_to_int.get(s2);
		a.setInfo(l, l);
		a.setInfo(k, k);
		a.addEdge(l, k);
	}
	// citim benzinariile, le retinem in vectorul benzinarii
	// vectorul ap_benzinarii are semnificatia ca ap_benzinarii[i] = 1,
	// daca in orasul reprezentat de noddul i este benzinarie, o altfel
	cin >> nr_b;
	vector <string> benzinarii;
	vector <int> ap_benzinarii(n,0);
	for (int  i = 0; i < nr_b; i++) {
		cin >> s1;
		benzinarii.push_back(s1);
		ap_benzinarii[table_string_to_int.get(s1)] = 1;
	}
	// task 1
	// vectorul de grade interioare
	vector <int> degree = a.getDegree();
	// calculam maximul si pozitia sa 
	int max = 0;
	for (int i = 0; i < n; i++) {
		if (max < degree[i]) {
			max = degree[i];
		}
	}
	for (int i = 0; i < n; i++) {
		if (max == degree[i]) {
			string s = table_int_to_string.get(i);
			fout1 << s << " " << max << endl;
			break;
		}
	}
	// task 2
	// ctc este vectorul cu componente tare conexe
	// ap este un vector care are semnificatia ca ap[i] este componenta tare
	// conexa din care face parte nodul i
	vector <int> ap(n,0);
	vector <vector<int> > ctc = CTC(n, a, ap);
	// harta este valida daca si numai daca exista o singura componenta
	// tare conexa
	int sw = 0;
	if (ctc.size() > 1) {
		fout2 << "HARTA INVALIDA" <<endl;
	} else {
		fout2 << "HARTA VALIDA" << endl;
		fout3 << "Exista drum intre oricare doua orase" << endl;
		sw = 1;
	}
	//task 3
	cin >> nr_i;
	for (int i = 0; i < nr_i; i++) {
		cin >> s1;
		if (sw == 0) {
			int l = table_string_to_int.get(s1);
			// vectorul inaccesibile retine nodurile care sunt inaccesibile
			// nodului l
	 		vector <int> inaccesibile;
	 		get_towns_task3(l, ap, inaccesibile);
	 		// afisam orasele inaccesibile folosind cel de-al doilea 
	 		// hastable
			if (inaccesibile.size() > 0) {
				fout3 << "Orase inaccesibile pentru " << s1 <<": ";
				for (int j = 0; j < inaccesibile.size(); j++) {
					fout3 << table_int_to_string.get(inaccesibile[j]) << " ";
				}
				fout3 << endl;
			}
		}	
	}
	// task 4
	// determinam distanta dintre un oras si cea mai apropiata benzinarie
	// si apoi verificam daca ramane combustibil in rezervor
	int nr_4, cant, cant_per_unit;
	cin >> nr_4;
	for (int i = 0; i < nr_4; i++) {
		cin >> s1 >> cant >> cant_per_unit;
		int k = table_string_to_int.get(s1);
		int dist = BFS_dist(k, n, a, ap_benzinarii);
		if (cant - dist * cant_per_unit >= 0) {
			fout4 <<"DA " << cant - dist * cant_per_unit << endl;
		} else {
			fout4 <<"NU" << endl;
		}
	}
	// task 5
	// retinem datele intr-un vector de structuri task5_t
	int nr_5, loc;
	vector <task5_t> trasee;
	vector <task5_t> trasee_dist;
	cin >> nr_5;
	for (int i = 0; i < nr_5; i++) {
		cin >> s1 >> s2 >> loc;
		task5_t traseu;
		traseu.s1 = s1;
		traseu.s2 = s2;
		traseu.passagers = loc;
		trasee.push_back(traseu);
	}
	// sortam vectorul folosind functia de comparare a doua structuri de la
	// inceputul programului
	sort(trasee.begin(), trasee.begin() + trasee.size(), compare_function);
	// vrem sa determinam un nou vector care are trasee distincte si in care
	// am adunat pasagerii traseelor identice
	int k = 0;
	while (k < trasee.size()) {
		int j = k+1;
		int s = trasee[k].passagers;
		while ( j < trasee.size() && trasee[j].s1 == trasee[k].s1 && trasee[j].s2 == trasee[k].s2) {
			s += trasee[j].passagers;
			j++;
		}
		trasee[k].passagers = s;
		trasee_dist.push_back(trasee[k]);
		k = j;
	}
	// determinam traseul cu numar maxim de pasageri
	int max_passagers = 0;
	for (int i = 0; i < trasee_dist.size(); i++) {
		if (max_passagers < trasee_dist[i].passagers) {
			max_passagers = trasee_dist[i].passagers;
			s1 = trasee_dist[i].s1;
			s2 = trasee_dist[i].s2;
		}
	}
	// determinam un drum minim intre capetele traseului cu numar maxim de pasageri
	// folosind functia BFS
	// traseul este costruit apoi facand pop la stiva cat timp nu e goala
	fout5 << max_passagers << " ";
	stack <int> road;
	BFS(table_string_to_int.get(s1), table_string_to_int.get(s2), n, a, road);
	while (!road.empty()) {
		int l = road.top();
		fout5 << table_int_to_string.get(l) << " ";
		road.pop();
	}
	fout5 << endl;
	return 0;
}