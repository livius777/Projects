//Copyright Liviu Chirimbu
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>
#include <string.h>
#include <complex.h>

#define PI atan2(1, 1) * 4

int N; //number of samples
char* input; //input file
char* output; //output file
int P; //number of threads
double* x; //input real points
complex* X; //output complex points
complex* X_copy; //used for copy of X
pthread_barrier_t barrier;
//get the arguments
void getArgs(int argc, char **argv)
{
	input = strdup(argv[1]);
	output = strdup(argv[2]);
	P = atoi(argv[3]);
}
//read from the input file, allocate space for x, X, X_copy
//intially X = x (as complex numbers)
void read_file() {
	FILE* f = fopen(input, "r");
	if (f == NULL) {
		printf("Failed to open input file\n");
		exit(1);
	}
	if (fscanf(f, "%d", &N)) {};

	x = (double*) malloc(N * sizeof(double));
	X = (complex*) calloc(N, sizeof(complex));
	X_copy = (complex*) malloc(N * sizeof(complex));

	for (int i = 0; i < N; i++) {
		if (fscanf(f, "%lf", &x[i])) {};
		X[i] = x[i] + I * 0;
		X_copy[i] = X[i];
	}
	fclose(f);

}
//function that write to the output file
void write_to_output() {
	FILE* f = fopen(output, "w");
	if (f == NULL) {
		printf("Failed to open output file\n");
		exit(1);
	}

	fprintf(f, "%d\n", N);
	for (int i = 0;  i < N - 1; i++) {
		fprintf(f, "%lf %lf\n", creal(X[i]), cimag(X[i]));
	}
	fprintf(f, "%lf %lf", creal(X[N - 1]), cimag(X[N - 1]));
	fclose(f);
}
//cleanup the memory
void free_memory() {
	free(input);
	free(output);
	free(x);
	free(X);
	free(X_copy);
}
//function that construct an useful array that will be used to compute parallel fft in iterative form
//this is O(N), see proof at the end
//in order to cumpute fft of N points, we need to compute fft for the even indices points, then for the
//odd indices points and then combine the result and so on
//for instance if N = 8, we need to compute fft of points 0,2,4,6 and 1,3,5,7
//for fft of 0,2,4,6 => fft of 0, 4 and fft of 2, 6
//for fft of 1,3,5,7 => fft of 1, 5 and fft of 3, 7
//arr will be 0, 4, 2, 6, 1, 3, 5, 7
//notice that we can now group the points easly, first time in consecutive blocks of 2 points((0, 4), (2, 6), (1, 5), (3,7))
//of which we compute fft then in consecutive block of 4 points and we compute fft for each block and lastly one block of 8 points
//and one final fft
int* construct_useful_array() {
	int* useful_array = (int*) malloc(N * sizeof(int));
	useful_array[0] = 0;
	useful_array[N / 2] = 1;
	for (int step = 2; step < N; step *= 2) {
		int* aux_par = (int *) malloc(step / 2 * sizeof(int));
		int* aux_impar = (int *) malloc(step / 2 * sizeof(int));
		for (int i = 0; i < step/ 2; i++) {
			aux_par[i] = useful_array[i];
			aux_impar[i] = useful_array[i + N / 2];
		}
		int j = 0;
		for (int i = 0; i < step; i += 2) {
			useful_array[i] = aux_par[j];
			useful_array[i + 1] = aux_par[j] + step;
			j++;
		}
		j = 0;
		for (int i = 0; i < step; i += 2) {
			useful_array[i + N / 2] = aux_impar[j];
			useful_array[i +  N / 2 + 1] = aux_impar[j] + step;
			j++;
		}
		free(aux_par);
		free(aux_impar);
	}
	return useful_array;
}
//compute fft for one block of length size, even points in the first half and odd points in the second half
//we copy the block obtained in X_copy
void compute_fft(int start, int size) {
	for (int i = 0; i < size; i++) {
		int k1 = i;
		int k2 = i;
		if (i >= size / 2) {
			k1 = i - size / 2;
			k2 = k1;
		}
		X_copy[start + i] = X[k1 + start] + cexp(-2 * PI * I * i / size) * X[k2 + start + size / 2];
	}
}
//the thread function
//at each step we calculate fft for the blocks of size 2, 4, 8, ..., N, given that we already calculated fft
//for blocks of half size; at the end of each step we recopy the new vector X_copy into X
//each thread will execute an aproximate equal number of operations
void* paralell_FFT(void *arg) {
	int thread_id = *(int *)arg;
	//When step = 2 ^ i, we calculate fft for blocks of size = step, given that we already calculated fft of size = step / 2
	for (int step = 2; step <= N; step *= 2) {
		int group_size = N / step / P;
		int start = thread_id * group_size;
		int end = thread_id == P - 1 ? (N / step - 1) : start + group_size - 1;
		for (int i = start; i <= end; i++) {
			compute_fft(i * step, step);
		}
		//wait to finish the level
		pthread_barrier_wait(&barrier);
		group_size = N / P;
		start = thread_id * group_size;
		end = thread_id == P - 1 ? N - 1 : start + group_size - 1;
		for (int i = start; i <= end; i++) {
			X[i] = X_copy[i];
		}
		//wait to copy X_copy to X
		pthread_barrier_wait(&barrier);
	}
	return NULL;
}
int main(int argc, char * argv[]) {
	
	getArgs(argc, argv);
	read_file();
	int* arr = construct_useful_array();
	//put X in a convenable form to easly execute fft
	for (int i = 0; i < N; i++) {
		X[i] = X_copy[arr[i]];
	}
	//create and execute the threads
	pthread_t tid[P];
	int thread_id[P];

	for(int i = 0; i < P; i++) {
		thread_id[i] = i;
	}

	pthread_barrier_init(&barrier, NULL, P);

	for(int i = 0; i < P; i++) {
		pthread_create(&tid[i], NULL, paralell_FFT, &thread_id[i]);
	}

	for(int i = 0; i < P; i++) {
		pthread_join(tid[i], NULL);
	}

	write_to_output();
	
	free_memory();
	free(arr);
	
	pthread_barrier_destroy(&barrier);
	return 0;
}
//********************************************************************************************
//Proof that construct_useful_array takes O(N) time
//at each step we fill two arrays of size step / 2 then we fill useful_array on step + step positions
//so there are 3 * step operations
//we get 3 * 2 + 3 * 2 ^ 2 + ... + 3 * 2 ^ tmax = 3 * 2 * (2 ^ tmax - 1) /(2 - 1) = 6 * (N / 2 - 1) = 3 * N - 6 operations
//so we have O(N) complexity 