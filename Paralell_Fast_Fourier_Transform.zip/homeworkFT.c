#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <math.h>
#include <string.h>
#include <complex.h>

#define PI atan2(1, 1) * 4

int N; //number of samples
char* input; //input file
char* output; //output file
int P; //number of threads
double* x; //input real points
complex* X; //output complex points

//function that get the arguments
void getArgs(int argc, char **argv)
{
	input = strdup(argv[1]);
	output = strdup(argv[2]);
	P = atoi(argv[3]);
}
//function that read from the input file and allocate space for x and X; it also fill x
void read_file() {
	FILE* f = fopen(input, "r");
	if (f == NULL) {
		printf("Failed to open input file\n");
		exit(1);
	}
	if (fscanf(f, "%d", &N)) {};

	x = (double*) malloc(N * sizeof(double));
	X = (complex*) calloc(N, sizeof(complex));

	for (int i = 0; i < N; i++) {
		if (fscanf(f, "%lf", &x[i])) {};
	}
	fclose(f);

}
//function that write to the output file
void write_to_output() {
	FILE* f = fopen(output, "w");
	if (f == NULL) {
		printf("Failed to open output file\n");
		exit(1);
	}

	fprintf(f, "%d\n", N);
	for (int i = 0;  i < N - 1; i++) {
		fprintf(f, "%lf %lf\n", creal(X[i]), cimag(X[i]));
	}
	fprintf(f, "%lf %lf", creal(X[N - 1]), cimag(X[N - 1]));
	fclose(f);
}
//cleanup the memory
void free_memory() {
	free(input);
	free(output);
	free(x);
	free(X);
}
//calculate X_k = sum(x_n * exp(- 2 * pi * i * k * n / N)), n from 0 to N - 1
void compute_point(int k) {
	for (int i = 0; i < N; i++) {
		X[k] += x[i] * cexp(-I * 2 * PI * k * i / N);
	}
}
//function that it executed by each thread
//each thread will compute aproximately N / P points from X using the above function
void* paralell_DFT(void* arg) {
	int thread_id = *(int *) arg;

	int group_size = N / P;
	int start = thread_id * group_size;
	int end = thread_id == P - 1 ? N - 1 : start + group_size - 1;
	for (int i = start; i <= end; i++) {
		compute_point(i);
	}
	return NULL;
}

int main(int argc, char * argv[]) {
	
	getArgs(argc, argv);
	read_file();
	//create the threads and execute them
	pthread_t tid[P];
	int thread_id[P];

	for(int i = 0; i < P; i++) {
		thread_id[i] = i;
	}
	
	for(int i = 0; i < P; i++) {
		pthread_create(&tid[i], NULL, paralell_DFT, &thread_id[i]);
	}
	
	for(int i = 0; i < P; i++) {
		pthread_join(tid[i], NULL);
	}

	write_to_output();

	free_memory();
	return 0;
}
