
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/kprobes.h>
#include <linux/ktime.h>
#include <linux/limits.h>
#include <linux/sched.h>
#include <asm/atomic.h>
#include <linux/slab.h>
#include <linux/list.h>
#include <linux/hashtable.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/uaccess.h>
#include <linux/string.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/wait.h>
#include <linux/miscdevice.h>
#include "tracer.h"

#define MAX 				50
#define MAX_SIZE			512

static char func_name[7][MAX] = {"__kmalloc", "kfree", "schedule", "up",
				"down_interruptible", "mutex_lock_nested", "mutex_unlock"};

static struct proc_dir_entry *proc_list_read;

struct process_data {
	char name[MAX];
	int num_calls;
	int allocated_mem;
	int free_mem;
};

struct info_list{
	struct process_data data;
	struct list_head list;
};

struct h_node {
    struct hlist_node node;
    struct list_head list_stats;
    pid_t pid;
};

struct alloc {
	struct hlist_node node;
	pid_t pid;
	unsigned long address;
	int allocated_memory;
};

static struct hlist_head tbl[MAX_SIZE];
static struct hlist_head addresses[MAX_SIZE];

static DEFINE_SPINLOCK(lock);

static unsigned int hash32(int a)
{
   a = (a + 0x7ed55d16) + (a<<12);
   a = (a ^ 0xc761c23c) ^ (a>>19);
   a = (a + 0x165667b1) + (a<<5);
   a = (a + 0xd3a2646c) ^ (a<<9);
   a = (a + 0xfd7046c5) + (a<<3);
   a = (a ^ 0xb55a4f09) ^ (a>>16);
   return a % MAX_SIZE;
}


static int query(pid_t pid, char query[MAX]) {
	unsigned int key = hash32(pid);
	struct h_node *__current = NULL;

	struct list_head *pos = NULL;
	struct info_list *info = NULL;


	rcu_read_lock(); 

	hash_for_each_possible_rcu(tbl, __current, node, key) {
		if (!strcmp(query, "kmalloc_mem")) {
			spin_lock(&lock);
			list_for_each(pos, &__current->list_stats) {
				info = list_entry(pos, struct info_list, list);
				if (!strcmp(info->data.name, "kmalloc")) {
					rcu_read_unlock();
					spin_unlock(&lock);
					return info->data.allocated_mem;
				}
			}
			spin_unlock(&lock);
		} else if (!strcmp(query, "kfree_mem")) {
			spin_lock(&lock);
			list_for_each(pos, &__current->list_stats) {
				info = list_entry(pos, struct info_list, list);
				if (!strcmp(info->data.name, "kfree")) {
					rcu_read_unlock();
					spin_unlock(&lock);
					return info->data.free_mem;
				}
			}
			spin_unlock(&lock);
		} else {
			spin_lock(&lock);
			list_for_each(pos, &__current->list_stats) {
				info = list_entry(pos, struct info_list, list);
				if (!strcmp(info->data.name, query)) {
					rcu_read_unlock();
					spin_unlock(&lock);
					return info->data.num_calls;
				}
			}
			spin_unlock(&lock);
		}
	}

	rcu_read_unlock();
	return 0;
}

static struct info_list* info_alloc(char name[MAX]) {
	struct info_list *info;

	info = kmalloc(sizeof(*info), GFP_KERNEL);

	if (!info) {
		return NULL;
	}

	strcpy(info->data.name, name);
	info->data.num_calls = 0;
	info->data.allocated_mem = 0;
	info->data.free_mem = 0;

	return info;
}

static void print_hashtable(void) {
	struct h_node *__current = NULL;
	unsigned int bkt;

	struct list_head *p;

	struct info_list *info;

	rcu_read_lock();

	hash_for_each_rcu(tbl, bkt, __current, node) {
		list_for_each(p, &__current->list_stats) {
			info = list_entry(p, struct info_list, list);
			pr_info("PID %d, %s = %d calls, %d allocated memory, %d free memory\n",
				__current->pid, info->data.name, info->data.num_calls,
				info->data.allocated_mem, info->data.free_mem);
		}
	}

	rcu_read_unlock();
}

static void print_hashtable_addresses(void) {
	struct alloc *__current = NULL;
	unsigned int bkt;

	rcu_read_lock();

	hash_for_each_rcu(addresses, bkt, __current, node) {
		pr_info("PID %d, address 0x%ld, allocated %d bytes of memory\n",
			__current->pid, __current->address, __current->allocated_memory);
	}

	rcu_read_unlock();
}

static int get_allocated_memory(pid_t pid, unsigned long address) {
	struct alloc *__current = NULL;
	unsigned int key = hash32(address);

	rcu_read_lock();

	hash_for_each_possible_rcu(addresses, __current, node, key) {
		if (__current->pid == pid && __current->address == address) {
			rcu_read_unlock();
			return __current->allocated_memory;
		}
	}

	rcu_read_unlock();

	return 0;
}

static int add_process(pid_t pid) {
	unsigned int key = hash32(pid);
	struct h_node *a;
	a = kmalloc(sizeof(*a), GFP_KERNEL);

	if (!a) {
		return -ENOMEM;
	}

	a->pid = pid;

	INIT_LIST_HEAD(&a->list_stats);

	struct info_list *info;

	info = info_alloc("kmalloc");

	if (!info) {
		return -ENOMEM;
	}

	list_add_tail(&info->list, &a->list_stats);

	info = info_alloc("kfree");

	if (!info) {
		return -ENOMEM;
	}

	list_add_tail(&info->list, &a->list_stats);

	info = info_alloc("sched");

	if (!info) {
		return -ENOMEM;
	}

	list_add_tail(&info->list, &a->list_stats);

	info = info_alloc("up");

	if (!info) {
		return -ENOMEM;
	}

	list_add_tail(&info->list, &a->list_stats);

	info = info_alloc("down");

	if (!info) {
		return -ENOMEM;
	}

	list_add_tail(&info->list, &a->list_stats);

	info = info_alloc("lock");

	if (!info) {
		return -ENOMEM;
	}

	list_add_tail(&info->list, &a->list_stats);

	info = info_alloc("unlock");

	if (!info) {
		return -ENOMEM;
	}

	list_add_tail(&info->list, &a->list_stats);

	spin_lock(&lock);
	hash_add_rcu(tbl, &a->node, key);
	spin_unlock(&lock);

	pr_info("Added process with PID %d\n", pid);

	return 0;
}

static int is_trackble(pid_t pid) {
	struct h_node *__current = NULL;
	unsigned int bkt;

	rcu_read_lock();

	hash_for_each_rcu(tbl, bkt, __current, node) {
		if (__current->pid == pid) {
			rcu_read_unlock();
			return 1;
		}
	}

	rcu_read_unlock();

	return 0;
}

static void modify_process(pid_t pid, char name[MAX], int num_calls, int allocated_mem, int free_mem) {
	unsigned int key = hash32(pid);

	struct h_node *__current;

	struct list_head *p;

	struct info_list *info;

	rcu_read_lock();

	hash_for_each_possible_rcu(tbl, __current, node, key) {
		if (__current->pid == pid) {
			list_for_each(p, &__current->list_stats) {
				info = list_entry(p, struct info_list, list);
				if (!strcmp(info->data.name, name)) {
					info->data.num_calls += num_calls;
					pr_info("%s has %d calls\n", info->data.name, info->data.num_calls);
					info->data.allocated_mem += allocated_mem;
					info->data.free_mem += free_mem;
				}
			}
		}
	}

	rcu_read_unlock();
}

static void remove_process(pid_t pid) {
	unsigned int key = hash32(pid);

	struct h_node *__current = NULL, *to_delete = NULL;
	struct hlist_node *tmp1;

	struct list_head *p, *tmp2;

	struct info_list *info;


	rcu_read_lock();

	hash_for_each_possible_rcu(tbl, __current, node, key) {
		if (__current->pid == pid) {
			to_delete = __current;
			break;
		}
	}

	rcu_read_unlock();

	if (!to_delete) {
		return;
	}

	spin_lock(&lock);
	hash_del_rcu(&to_delete->node);
	spin_unlock(&lock);
	synchronize_rcu();


	list_for_each_safe(p, tmp2, &to_delete->list_stats) {
		info = list_entry(p, struct info_list, list);
		list_del(p);
		kfree(info);
	}

	kfree(to_delete);

	pr_info("Removed process with PID %d\n", pid);
}

static void my_free_memory(void) {

	struct h_node *__current;
	struct hlist_node *tmp;

	unsigned int bkt;

	struct list_head *p, *tmp2;

	struct info_list *info;

	hash_for_each_safe(tbl, bkt, tmp, __current, node)	{
		list_for_each_safe(p, tmp2, &__current->list_stats) {
			info = list_entry(p, struct info_list, list);
			list_del(p);
			kfree(info);
		}
		hash_del(&__current->node);
		kfree(__current);
	}
}

static int my_open(struct inode *inode, struct file *file)
{
	//printk("Open called!\n");

	return 0;
}

static int
my_release(struct inode *inode, struct file *file)
{
	//printk("Close called!\n");
	return 0;
}

static long
my_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	struct my_cdev *data = (struct my_cdev *) file->private_data;
	int ret = 0;
	int remains;
	pid_t pid =(pid_t) arg;
	switch (cmd) {
		case TRACER_ADD_PROCESS:
			add_process(pid);
			//print_hashtable();
			break;
		case TRACER_REMOVE_PROCESS:
			remove_process(pid);
			//print_hashtable();
			break;
		default:
		ret = -EINVAL;
	}

	return ret;
}

static const struct file_operations fops = {
    .owner          = THIS_MODULE,
    .open           = my_open,
    .release        = my_release,
    .unlocked_ioctl = my_ioctl
};

struct miscdevice misc_device = {
    .minor = TRACER_DEV_MINOR,
    .name = TRACER_DEV_NAME,
    .fops = &fops,
};

static int my_cdev_init(void)
{
	int err;
	int i;

	/* TODO 1: register char device region for MY_MAJOR and NUM_MINORS starting at MY_MINOR */
	err = misc_register(&misc_device);

	if (err != 0) {
		pr_info("Failed with error code %d\n", err);
		return err;
	}

	//pr_info("Device succesfully registered!\n");

	return 0;
}

static void my_cdev_exit(void)
{
	misc_deregister(&misc_device);
	//pr_info("Device succesfully unregistred!\n");
}

static int list_proc_show(struct seq_file *m, void *v)
{
	/* TODO 3: print your list. One element / line. */
	
	struct h_node *__current = NULL;
	unsigned int bkt;

	seq_puts(m, "PID    kmalloc    kfree    kmalloc_mem    kfree_mem    sched    up    down    lock    unlock\n");

	rcu_read_lock();

	hash_for_each_rcu(tbl, bkt, __current, node) {
		pid_t pid = __current->pid;
		seq_printf(m, "%d    ", pid);

		int res = query(pid, "kmalloc");
		pr_info("PID %d Kmalloc %d\n", pid, res);
		seq_printf(m, "%d    ", res);

		res = query(pid, "kfree");
		pr_info("PID %d Kfree %d\n", pid, res);
		seq_printf(m, "%d    ", res);

		res = query(pid, "kmalloc_mem");
		pr_info("PID %d Kmalloc Memory %d\n", pid, res);
		seq_printf(m, "%d    ", res);

		res = query(pid, "kfree_mem");
		pr_info("PID %d Kfree Memory %d\n", pid, res);
		seq_printf(m, "%d    ", res);

		res = query(pid, "sched");
		pr_info("PID %d Sched %d\n", pid, res);
		seq_printf(m, "%d    ", res);

		res = query(pid, "up");
		pr_info("PID %d Up %d\n", pid, res);
		seq_printf(m, "%d    ", res);

		res = query(pid, "down");
		pr_info("PID %d Down %d\n", pid, res);
		seq_printf(m, "%d    ", res);

		res = query(pid, "lock");
		pr_info("PID %d Lock %d\n", pid, res);
		seq_printf(m, "%d    ", res);

		res = query(pid, "unlock");
		pr_info("PID %d Unlock %d\n", pid, res);
		seq_printf(m, "%d\n", res);
	}

	rcu_read_unlock();

	return 0;
}

static int list_read_open(struct inode *inode, struct  file *file)
{
	return single_open(file, list_proc_show, NULL);
}

static const struct proc_ops r_pops = {
	.proc_open		= list_read_open,
	.proc_read		= seq_read,
	.proc_release	= single_release,
};

static int entry_handler_kmalloc(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	*((int *) ri->data) = regs->ax;
	//pr_info("Allocated %d bytes\n", regs->ax);
	if (is_trackble(current->pid)) {
		//pr_info("PID %d\n", current->pid);
		modify_process(current->pid, "kmalloc", 1, 0, 0);
		//print_hashtable();
	}
	return 0;
}


static int entry_handler_kfree(struct kretprobe_instance *ri, struct pt_regs *regs)
{


	if (is_trackble(current->pid)) {
		pr_info("PID %d kfree\n", current->pid);
		unsigned long address = regs->ax;
		//pr_info("Freeing address 0x%ld\n", address);
		//pr_info("PID ceva%d\n", current->pid);
		int free_memory = get_allocated_memory(current->pid, address);
		//pr_info("Freeing %d bytes of memory\n", free_memory);
		modify_process(current->pid, "kfree", 1, 0, free_memory);
		//print_hashtable();
	}
	return 0;
}


static int entry_handler_sched(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	if (is_trackble(current->pid)) {
		pr_info("PID %d sched\n", current->pid);
		modify_process(current->pid, "sched", 1, 0, 0);
		//print_hashtable();
	}
	return 0;
}

static int entry_handler_up(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	if (is_trackble(current->pid)) {
		pr_info("PID %d up\n", current->pid);
		modify_process(current->pid, "up", 1, 0, 0);
		//print_hashtable();
	}
	return 0;
}

static int entry_handler_down(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	if (is_trackble(current->pid)) {
		pr_info("PID %d down\n", current->pid);
		modify_process(current->pid, "down", 1, 0, 0);
		//print_hashtable();
	}

	return 0;
}

static int entry_handler_lock(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	if (is_trackble(current->pid)) {
		pr_info("PID %d lock\n", current->pid);
		modify_process(current->pid, "lock", 1, 0, 0);
		//print_hashtable();
	}
	
	return 0;
}

static int entry_handler_unlock(struct kretprobe_instance *ri, struct pt_regs *regs)
{
	if (is_trackble(current->pid)) {
		pr_info("PID %d unlock\n", current->pid);
		modify_process(current->pid, "unlock", 1, 0, 0);
		//print_hashtable();
	}
	
	return 0;
}

static int ret_handler_kmalloc(struct kretprobe_instance *ri, struct pt_regs *regs)
{

	int size = *((int *)ri->data);
	unsigned long address = regs_return_value(regs);

	if (is_trackble(current->pid)) {
		pr_info("PID %d kmalloc\n", current->pid);
		struct alloc *mem_alloc;
		mem_alloc = kmalloc(sizeof(*mem_alloc), GFP_ATOMIC);
		if (!mem_alloc) {
			return -ENOMEM;
		}
		mem_alloc->pid = current->pid;
		mem_alloc->allocated_memory = size;
		mem_alloc->address = address;

		spin_lock(&lock);
		hash_add_rcu(addresses, &mem_alloc->node, hash32(address));
		spin_unlock(&lock);

		modify_process(current->pid, "kmalloc", 0, size, 0);

		//print_hashtable();
	}
	
	return 0;
}

static struct kretprobe my_kretprobe_unlock = {
	.entry_handler	= entry_handler_unlock,
	/* Probe up to 20 instances concurrently. */
	.maxactive		= 64,
};

static struct kretprobe my_kretprobe_lock = {
	.entry_handler	= entry_handler_lock,
	/* Probe up to 20 instances concurrently. */
	.maxactive		= 64,
};

static struct kretprobe my_kretprobe_kmalloc = {
	.handler		= ret_handler_kmalloc,
	.entry_handler	= entry_handler_kmalloc,
	/* Probe up to 20 instances concurrently. */
	.maxactive		= 64,
};

static struct kretprobe my_kretprobe_kfree = {
	.entry_handler	= entry_handler_kfree,
	/* Probe up to 20 instances concurrently. */
	.maxactive		= 64,
};

static struct kretprobe my_kretprobe_sched = {
	.entry_handler	= entry_handler_sched,
	/* Probe up to 20 instances concurrently. */
	.maxactive		= 64,
};

static struct kretprobe my_kretprobe_up = {
	.entry_handler	= entry_handler_up,
	/* Probe up to 20 instances concurrently. */
	.maxactive		= 64,
};

static struct kretprobe my_kretprobe_down = {
	.entry_handler	= entry_handler_down,
	/* Probe up to 20 instances concurrently. */
	.maxactive		= 64,
};

static void unregister_probes(void) {
	unregister_kretprobe(&my_kretprobe_kmalloc);
	unregister_kretprobe(&my_kretprobe_kfree);
	unregister_kretprobe(&my_kretprobe_sched);
	unregister_kretprobe(&my_kretprobe_up);
	unregister_kretprobe(&my_kretprobe_down);
	unregister_kretprobe(&my_kretprobe_lock);
	unregister_kretprobe(&my_kretprobe_unlock);
}

static int __init kretprobe_init(void)
{
	int ret;

	proc_list_read = proc_create(TRACER_DEV_NAME, 0000, NULL,
				     &r_pops);
	if (!proc_list_read){
		goto proc_list_cleanup;
	}

	hash_init(tbl);
	hash_init(addresses);

	my_cdev_init();

	my_kretprobe_kmalloc.kp.symbol_name = func_name[0];
	my_kretprobe_kfree.kp.symbol_name = func_name[1];
	my_kretprobe_sched.kp.symbol_name = func_name[2];
	my_kretprobe_up.kp.symbol_name = func_name[3];
	my_kretprobe_down.kp.symbol_name = func_name[4];
	my_kretprobe_lock.kp.symbol_name = func_name[5];
	my_kretprobe_unlock.kp.symbol_name = func_name[6];

	ret = register_kretprobe(&my_kretprobe_kmalloc);
	if (ret < 0) {
		pr_err("register_kretprobe failed, returned %d\n", ret);
		goto unregister_probes_0;
	}

	ret = register_kretprobe(&my_kretprobe_kfree);
	if (ret < 0) {
		pr_err("register_kretprobe failed, returned %d\n", ret);
		goto unregister_probes_1;
	}

	ret = register_kretprobe(&my_kretprobe_sched);
	if (ret < 0) {
		pr_err("register_kretprobe failed, returned %d\n", ret);
		goto unregister_probes_2;
	}

	ret = register_kretprobe(&my_kretprobe_up);
	if (ret < 0) {
		pr_err("register_kretprobe failed, returned %d\n", ret);
		goto unregister_probes_3;
	}

	ret = register_kretprobe(&my_kretprobe_down);
	if (ret < 0) {
		pr_err("register_kretprobe failed, returned %d\n", ret);
		goto unregister_probes_4;
	}

	ret = register_kretprobe(&my_kretprobe_lock);
	if (ret < 0) {
		pr_err("register_kretprobe failed, returned %d\n", ret);
		goto unregister_probes_5;
	}

	ret = register_kretprobe(&my_kretprobe_unlock);
	if (ret < 0) {
		pr_err("register_kretprobe failed, returned %d\n", ret);
		goto unregister_probes_6;
	}

	return 0;

unregister_probes_6:
	unregister_kretprobe(&my_kretprobe_lock);
	unregister_kretprobe(&my_kretprobe_down);
	unregister_kretprobe(&my_kretprobe_up);
	unregister_kretprobe(&my_kretprobe_sched);
	unregister_kretprobe(&my_kretprobe_kfree);
	unregister_kretprobe(&my_kretprobe_kmalloc);
	proc_remove(proc_list_read);
	return ret;

unregister_probes_5:
	unregister_kretprobe(&my_kretprobe_down);
	unregister_kretprobe(&my_kretprobe_up);
	unregister_kretprobe(&my_kretprobe_sched);
	unregister_kretprobe(&my_kretprobe_kfree);
	unregister_kretprobe(&my_kretprobe_kmalloc);
	proc_remove(proc_list_read);
	return ret;

unregister_probes_4:
	unregister_kretprobe(&my_kretprobe_up);
	unregister_kretprobe(&my_kretprobe_sched);
	unregister_kretprobe(&my_kretprobe_kfree);
	unregister_kretprobe(&my_kretprobe_kmalloc);
	proc_remove(proc_list_read);
	return ret;

unregister_probes_3:
	unregister_kretprobe(&my_kretprobe_sched);
	unregister_kretprobe(&my_kretprobe_kfree);
	unregister_kretprobe(&my_kretprobe_kmalloc);
	proc_remove(proc_list_read);
	return ret;

unregister_probes_2:
	unregister_kretprobe(&my_kretprobe_kfree);
	unregister_kretprobe(&my_kretprobe_kmalloc);
	proc_remove(proc_list_read);
	return ret;

unregister_probes_1:
	unregister_kretprobe(&my_kretprobe_kmalloc);
	proc_remove(proc_list_read);
	return ret;

unregister_probes_0:
	proc_remove(proc_list_read);
	return ret;

proc_list_cleanup:
	proc_remove(proc_list_read);
	return -ENOMEM;


}

static void __exit kretprobe_exit(void)
{
	my_cdev_exit();

	my_free_memory();

	unregister_probes();

	proc_remove(proc_list_read);
}

module_init(kretprobe_init);
module_exit(kretprobe_exit);
MODULE_LICENSE("GPL");
