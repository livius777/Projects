// Copyright Liviu Iulian Chirimbu 2017
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
// structura pentru a retine pointerul catre primul octet din
// arena si lungimea arenei
typedef struct {
    unsigned char *start;
    int lenght;
} arena;
// structura pentru a retine o comanda
// in cmd se retine primul cuvant, apoi maxim 3 argumente intregi
// in for_show se retin daca e cazul argumentul comenzii SHOW
typedef struct {
    char cmd[30];
    int x1, x2, x3;
    char for_show[30];
} comanda;
// functie care aloca N octeti, pecare ii seteaza la zero si implicit
// seteaza indicele de start pe 0
void initialize(int N, arena *a) {
    a->start = (unsigned char *) calloc(N, sizeof(unsigned char));
    if (a->start == NULL) {
        exit(1);
    }
    a->lenght = N;
}
// functie pentru a elibera memoria alocata si care incheie programul
void finalize(arena *a) {
    free(a->start);
}
// functie pentru alocarea unui bloc nou in primul spatiu liber gasit
void alloc(int size, arena *a) {
    // cazul in care arena nu are niciun bloc alocat
    if (*((int *)a->start) == 0) {
        *((int*) a->start) = 4;
        if (a->lenght - 4 < 12 + size) {
            printf("%d\n", 0);
            return;
        }
        unsigned char *cbloc = a->start + *((int*) a->start);
        int *ibloc = (int *) cbloc;
        *ibloc = 0;
        *(ibloc+1) = 0;
        *(ibloc+2) = 12 + size;
        printf("%d\n", 12 + *((int*) a->start));
        return;
    } else {
       // daca arena are blocuri alocate, ne folosim de 2 pointeri
       // catre inceputul blocului curent si anterior
        unsigned char *ant = a->start;
        unsigned char *curent;
        curent = a->start + *((int*) a->start);
        int *int_ant = (int *) ant;
        int *int_curent = (int *) curent;
        // daca exista loc intre blocul de start si primul bloc
        if (*int_ant - 4 >= 12 + size) {
            unsigned char *char_blocnou = a->start + 4;
            int *int_blocnou = (int *) char_blocnou;
            *int_blocnou = *((int*) a->start);
            *(int_blocnou + 1) = 0;
            *(int_blocnou + 2) = 12 + size;
            *((int*) a->start) = 4;
            *(int_curent + 1) = 4;
            printf("%d\n", 12 + *((int*) a->start));
            return;
        }
        // daca nu, verificam daca e loc intre blocul curent
        // si blocul urmator
        while (*int_curent != 0) {
            int sp = *int_curent - *int_ant - *(int_curent + 2);
            if (sp >= 12 +size) {
                unsigned char *char_blocnou = curent + *(int_curent + 2);
                int *int_blocnou = (int *) char_blocnou;
                *int_blocnou = *int_curent;
                *(int_blocnou + 1) = *int_ant;
                *(int_blocnou + 2) = 12 + size;
                unsigned char *char_bloc_urm = a->start + *int_curent;
                int *int_bloc_urm = (int *) char_bloc_urm;
                *(int_bloc_urm + 1) = *int_ant + *(int_curent + 2);
                *int_curent = *int_ant + *(int_curent + 2);
                printf("%d\n", *int_curent + 12);
                return;
            }
            ant = curent;
            curent = a->start + *(int_curent);
            int_ant = (int *) ant;
            int_curent = (int *) curent;
        }
        // daca ajungem la ultimul bloc din arena verificam daca
        // mai sunt octeti liberi
        // in fiecare caz din cele de mai sus modificam legaturile
        // necesare dintre blocuri
        if (a->lenght - *(int_ant)- *(int_curent + 2) < 12 + size) {
            printf("%d\n", 0);
            return;
        } else {
            *int_curent = *int_ant + *(int_curent + 2);
            unsigned char *cblocnou = a->start + *int_curent;
            int *iblocnou = (int *) cblocnou;
            *iblocnou = 0;
            *(iblocnou + 1) = *int_ant;
            *(iblocnou + 2) = 12 + size;
            printf("%d\n", 12 + *int_curent);
            return;
        }
    }
}
// functie pentru afisarea arenei in formatul specificat din enunt
void dump(arena *a) {
    int i, j;
    for (i=0; i < a->lenght - 16; i = i + 16) {
        printf("%08X\t", i);
        for (j = 0; j < 16; j++) {
            printf("%02X ", *(a->start + i + j));
            if (j == 7) {
                printf(" ");
            }
        }
        printf("\n");
    }
    printf("%08X\t", i);
    for (j = i; j < a->lenght; j++) {
        printf("%02X ", *(a->start + j));
        if (j == i+7) {
            printf(" ");
        }
    }
    printf("\n%08X", a->lenght);
    printf("\n");
}
// functie care seteza ocetii de la indexul index pana la
// index + size -1 cu valoarea value
void fill(arena *a, int index, int size, int value) {
    int i;
    for (i= index; i < size + index; i++) {
        *(a->start + i) = value;
    }
}
// functie care elibereaza un bloc care incepe
// cu sectiunea de date de la indexul index
void freebloc(int index, arena *a) {
    // folosim un pointer catre inceputul blocului de eliminat
    unsigned char *cbloc_elimin = a->start + index - 12;
    int  *ibloc_elimin = (int *) cbloc_elimin;
    // cazul in care arena are doar un bloc
    if (*(ibloc_elimin) == 0 && *(ibloc_elimin+1)== 0) {
        *((int *)a->start) = 0;
        return;
    }
    // cazul in care sunt cel putin doua blocuri si il sterg
    // pe primul
    if (*ibloc_elimin != 0 && *(ibloc_elimin + 1) == 0) {
        unsigned char *cbloc_urm = a->start + *(ibloc_elimin);
        int  *ibloc_urm = (int *)cbloc_urm;
        *(ibloc_urm + 1) = 0;
        *((int *)a->start) = *(ibloc_elimin);
        return;
    }
    // cazul in care sunt cel putin doua blocuri si il sterg
    // pe ultimul bloc
    if (*ibloc_elimin == 0 && *(ibloc_elimin + 1) !=0) {
        unsigned char *cbloc_ant = a->start + *(ibloc_elimin + 1);
        int *ibloc_ant = (int *)cbloc_ant;
        (*ibloc_ant) = 0;
        return;
    }
    // cazul in care sterg un bloc aflat intre doua blocuri
    if (*ibloc_elimin != 0 && *(ibloc_elimin + 1) !=0) {
        unsigned char *cbloc_ant = a->start + *(ibloc_elimin + 1);
        int *ibloc_ant = (int *)cbloc_ant;
        unsigned char *cbloc_urm = a->start + *(ibloc_elimin);
        int  *ibloc_urm = (int *)cbloc_urm;

        *ibloc_ant = *ibloc_elimin;
        *(ibloc_urm + 1) = *(ibloc_elimin + 1);
    }
}
// functie pentru afisarea zonelor libere din arena
// si a numarului de octeti liberi
// tot ce presupune aceasta functie este practic parcurgerea
// arenei in doua cazuri : daca avem sau nu blocuri alocate
void show_free(arena *a) {
    int nroct = 0;
    int nrblocks = 0;
    if (*((int *)a->start) == 0) {
        nrblocks = 1;
        nroct = a->lenght - 4;
    } else {
        if (*((int *)a->start) > 4) {
            nroct = *((int *)a->start) - 4;
            nrblocks++;
        }
        unsigned char *cbloc_urm = a->start + *((int *)a->start);
        unsigned char *cbloc_ant = a->start;
        int *ibloc_urm = (int *) cbloc_urm;
        int *ibloc_ant = (int *) cbloc_ant;
        while (*ibloc_urm != 0) {
            if (*ibloc_urm - *(ibloc_ant) - *(ibloc_urm + 2) > 0) {
                nrblocks++;
                nroct += *ibloc_urm - *(ibloc_ant) - *(ibloc_urm + 2);
            }
            cbloc_ant = cbloc_urm;
            cbloc_urm = a->start + *ibloc_urm;
            ibloc_ant = (int *) cbloc_ant;
            ibloc_urm = (int *) cbloc_urm;
        }
        if ((a->lenght - *ibloc_ant - *(ibloc_urm + 2)) > 0) {
            nrblocks++;
            nroct += a->lenght - *ibloc_ant - *(ibloc_urm + 2);
        }
    }
    printf("%d blocks (%d bytes) free\n", nrblocks, nroct);
}
// functie pentru afisarea eficientei, a fragmentarii si a
// numarului de blocuri alocate
// tot ce presupune aceasta functie este practic parcurgerea
// arenei in doua cazuri : daca avem sau nu blocuri alocate
void show_usage(arena *a) {
    unsigned char *cbloc_urm = a->start + *((int *)a->start);
    unsigned char *cbloc_ant = a->start;
    int *ibloc_urm = (int *) cbloc_urm;
    int *ibloc_ant = (int *) cbloc_ant;
    int nrblocks_free = 0;
    if (*((int *)a->start) > 4) {
        nrblocks_free++;
    }
    int nroct_date = 0;
    int nroct_real = 4;
    int nrblock_used = 0;

    while (*ibloc_urm != 0) {
        nrblock_used++;
        nroct_real += *(ibloc_urm +2);
        nroct_date += *(ibloc_urm +2) - 12;
        if (*ibloc_urm - *ibloc_ant - *(ibloc_urm + 2) > 0) {
            nrblocks_free++;
        }
        cbloc_ant = cbloc_urm;
        cbloc_urm = a->start + *ibloc_urm;
        ibloc_ant = (int *) cbloc_ant;
        ibloc_urm = (int *) cbloc_urm;
    }
    nrblock_used++;
    nroct_real += *(ibloc_urm +2);
    nroct_date += *(ibloc_urm +2) - 12;
    if (a->lenght - *ibloc_ant - *(ibloc_urm + 2) > 0) {
        nrblocks_free++;
    }

    printf("%d blocks (%d bytes) used\n", nrblock_used, nroct_date);
    int eff;
    float aux = 100 * ((float) nroct_date / nroct_real);
    eff = (int) aux;
    printf("%d%%efficiency\n", eff);
    if (*((int *)a->start) == 0) {
        printf("0%%fragmentation\n");
        return;
    }
    int fragmentation;
    aux = 100 * (float)(nrblocks_free - 1)/(nrblock_used);
    fragmentation = (int) aux;
    printf("%d%%fragmentation\n", fragmentation);
}
// functie pentru a arata daca o zona este libera sau ocupata
// avand un numar de octeti in ea
// tot ce presupune aceasta functie este practic parcurgerea
// arenei in doua cazuri : daca avem sau nu blocuri alocate
void show_allocation(arena *a) {
    printf("OCCUPIED 4 bytes\n");
    if (*((int *)a->start) == 0) {
        printf("FREE %d bytes\n", a->lenght - 4);
    } else {
        if (*((int *)a->start) > 4) {
            printf("FREE %d bytes\n", *((int *)a->start) - 4);
        }
        unsigned char *cbloc_urm = a->start + *((int *)a->start);
        unsigned char *cbloc_ant = a->start;
        int *ibloc_urm = (int *) cbloc_urm;
        int *ibloc_ant = (int *) cbloc_ant;
        while (*ibloc_urm != 0) {
            printf("OCCUPIED %d bytes\n", *(ibloc_urm + 2));
            if (*ibloc_urm - *ibloc_ant - *(ibloc_urm + 2) > 0) {
                printf("FREE %d bytes\n",
                 *ibloc_urm - *ibloc_ant - *(ibloc_urm + 2));
            }
            cbloc_ant = cbloc_urm;
            cbloc_urm = a->start + *ibloc_urm;
            ibloc_ant = (int *) cbloc_ant;
            ibloc_urm = (int *) cbloc_urm;
        }
        printf("OCCUPIED %d bytes\n", *(ibloc_urm + 2));
        if (a->lenght - *ibloc_ant - *(ibloc_urm + 2) > 0) {
            printf("FREE %d bytes\n",
             a->lenght - *ibloc_ant - *(ibloc_urm + 2));
        }
    }
}
// functie pentru citirea unei comenzi
// folosim strtok pentru a separa cuvintele
// pe care le stocam in structura comanda
void read_comanda(comanda *c, char s[100]) {
    char *cuv;
    cuv = strtok(s, " \n");
    int nr = 0;
    while (cuv != NULL) {
        if (nr == 0) {
            strcpy(c->cmd, cuv);
        }
        if (nr == 1) {
            if (strcmp(c->cmd, "SHOW") == 0) {
                strcpy(c->for_show, cuv);
            } else {
            c->x1 = atoi(cuv);
            }
        }
        if (nr == 2) {
            c->x2 = atoi(cuv);
        }
        if (nr == 3) {
            c->x3 = atoi(cuv);
        }
        cuv = strtok(NULL, " \n");
        nr++;
    }
}

int main() {
    arena  a;
    char s[60];
    comanda c;
    // citirea pana la sfarsit de fisier si verificarea comenzii
    // care trebuie efectuata conform structurii comanda
    while (fgets(s, 60, stdin) != NULL) {
        read_comanda(&c, s);
        if (strcmp(c.cmd, "INITIALIZE") == 0) {
            initialize(c.x1, &a);
        }
        if (strcmp(c.cmd, "FINALIZE") == 0) {
            finalize(&a);
            exit(1);
        }
        if (strcmp(c.cmd, "ALLOC") == 0) {
            alloc(c.x1, &a);
        }
        if (strcmp(c.cmd, "DUMP") == 0) {
            dump(&a);
        }
        if (strcmp(c.cmd, "FREE") == 0) {
            freebloc(c.x1, &a);
        }
        if (strcmp(c.cmd, "FILL") == 0) {
            fill(&a, c.x1, c.x2, c.x3);
        }
        if (strcmp(c.cmd, "SHOW") == 0) {
            if (strcmp(c.for_show, "FREE") == 0) {
                show_free(&a);
            }
            if (strcmp(c.for_show, "USAGE") == 0) {
                show_usage(&a);
            }
            if  (strcmp(c.for_show, "ALLOCATIONS") ==0) {
                show_allocation(&a);
            }
        }
    }
    return 0;
}
