Liviu Chirimbu
332CA
					README

Acesta este readme-ul temei 1 de la EGC, cea a constat in implementarea unei variante a jocului Flappy bird.
Am folosit functia CreateMesh si transformarile 2D din laboratoarele 2 si 3. Implementarea a constat in urmatoarele:
i) Crearea pasarii -> o combinatie de forme geometrice, cea mai complexa fiind cercul care a fost creat folosind
coordonate polare si un numar mare de triughiuri("imaginea felii de pizza").
****************************************************************************
ii) Crearea unui patrat "mama" din care au fost create obstacolele prin translatie(toate obstacolele sunt situate
la aceeasi distanta unul de celalalt) si scalare pentru a crea dreptunghiuri de inaltimi diferite. Inaltimile
dreptunghiurilor sunt hardcodate.
In functia Update, se translateaza fiecare dreptunghi cu o distanta pe Ox spre stanga care creste mereu, in
functie de deltaTimeSeconds. Dreptunghiurile au fost randate in dreptunghiul ferestrei de afisare, ca si cum am avea o scena
de lungime dubla:
 ___________________________ ____________________________
|    scena reala            |                           |
|                           |                           |
|aici desenez  obstacolele  | aici redesenez obstacolele|
|___________________________|___________________________|
Astfel ca atunci cand un dreptunghi iese din scena, apare imediat desenul sau din "a doua 
parte a scenei duble" si se creeaza o animatie continua.Cand pasul de translatie devine egal cu
rezolutia pe Ox atunci refacem pasul de translatie la 0.
***********************************************************
iii) Animatia pasarii-> pasarea este afectata de acceleratie dupa legea y = h - g * t^2 / 2 si are tendita se sa incline in jos
la maxim 90 de grade fata de centrul pasarii ales la crearea pasarii. La apasarea tastei space, pasarea invinge acceleratia si se
roteste in sus fata de centru.
***********************************************************
iv) Coliziunile si scor -> am ales ca scorul sa creasca cu 10 de fiecare data cand pasarea ajunge in interiorul
unui obstacol, iar pentru coliziuni am folosit intersectia cercului care inconjoara pasarea cu un dreptunghi vertical,
care revine la a verifica ca distanta dintre centrul cercului si punctul din interiorul dreptunghiului cel mai apropiat de centrul
cercului este mai mica decat raza cercului.
************************************************************
Mai multe detalii legate de implementare se gasesc in comentariile din codul sursa.

