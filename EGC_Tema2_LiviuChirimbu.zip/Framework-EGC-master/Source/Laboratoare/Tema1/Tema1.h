#pragma once

#include <Component/SimpleScene.h>
#include <vector>
#include <Core/Engine.h>

class Tema1 : public SimpleScene
{
public:
	Tema1();
	~Tema1();
	
	void Init() override;

private:
	void FrameStart() override;
	void Update(float deltaTimeSeconds) override;
	void FrameEnd() override;

	void OnInputUpdate(float deltaTime, int mods) override;
	void OnKeyPress(int key, int mods) override;
	void OnKeyRelease(int key, int mods) override;
	void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
	void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
	void OnWindowResize(int width, int height) override;

	Mesh* CreateMesh(const char* name, const std::vector<VertexFormat>& vertices, const std::vector<unsigned short>& indices);
	void init_circle(float radius, std::vector<VertexFormat>& vertices, std::vector<unsigned short>& indices, glm::ivec2& center);
	bool colision(float radius, glm::ivec2& center, glm::ivec2& left_corner, float width, float length);
	void init_bird();
	void init_values();

protected:
	glm::mat3 modelMatrix; //matrice de modelare pentru dreptunghiuri
	glm::mat3 birdMatrix; //matrice de modelare pentru pasare
	float dist_forms; //distanta dintre dreptunghiuri
	float nb_forms; //numarul de dreptunghiuri (doar pe o parte)
	float l; //lungime dreptunghi
	float tr_Ox; //pasul de translatie pe axa Ox
	bool space; //pentru eveniment de apasare space
	float time; //pentru acceleratia pasarii
	float rotate_down, rotate_up; //rotatia pasarii
	int score; //scorul jucatorului
	int step; //folosit la calcularea scorului
	bool lost; //pentru a sti daca am pirdut
	float radius_bird; //raza cercului in care e incadrata pasarea
	float gravity; //pentru acceleratie
	std::vector<float> scale_down; //scalari dreptunghiuri de jos
	std::vector<float> scale_up; //scalari dreptunghiuri de sus
	std::vector<float> translate_OX; //vector pentru randarea in scena a dreptunghiurilor
	
};
