#include "Tema2.h"
#include "Transform3D.h"

#include <vector>
#include <string>
#include <iostream>

#include <Core/Engine.h>

using namespace std;

Tema2::Tema2()
{
}

Tema2::~Tema2()
{
}
 
void Tema2::gen_values() {
	for (int i = 0; i < nb_clouds; i++) {
		float alfa = (rand() % 200) / 200.0f + 1.0f;
		float x = (rand() % 200) / 200.0f - 1;
		float y = (rand() % 200) / 200.0f - 1;
		float z = (rand() % 200) / 200.0f - 1;
		for_clouds.push_back(alfa);
		for_clouds.push_back(x);
		for_clouds.push_back(y);
		for_clouds.push_back(z);

		copy_for_clouds.push_back(alfa);
		copy_for_clouds.push_back(x);
		copy_for_clouds.push_back(y);
		copy_for_clouds.push_back(z);
	}

	for (int i = 0; i < nb_spheres; i++) {
		float alfa = (rand() % 150) / 100.0f + 2.5f;
		float x = (rand() % 800) / 1000.0f - 0.4f;
		float y = (rand() % 1200) / 1000.0f - 0.6f;
		float z = 0.0f;

		for_spheres.push_back(alfa);
		for_spheres.push_back(x);
		for_spheres.push_back(y);
		for_spheres.push_back(z);

		copy_for_spheres.push_back(alfa);
		copy_for_spheres.push_back(x);
		copy_for_spheres.push_back(y);
		copy_for_spheres.push_back(z);
	}

	for (int i = 0; i < nb_teapots; i++) {
		int nr = rand() % 5 + 1;
		teapots_per_slice.push_back(nr);
	}
	
	inital_translate_teapot.push_back(glm::vec3(4, 0.2f - 6.4, 0));
	inital_translate_teapot.push_back(glm::vec3(4.2f, 0.15f - 6.3, 0));
	inital_translate_teapot.push_back(glm::vec3(4.4f, 0.05f - 6.2 , 0));
	inital_translate_teapot.push_back(glm::vec3(4.6f, -0.1f - 6, 0));
	inital_translate_teapot.push_back(glm::vec3(4.8f, -0.15f - 5.9, 0));

	for (int i = 0; i < nb_teapots; i++) {
		int nr = rand() % 5 + 1;
		teapots_per_slice.push_back(nr);
		float alfa = (rand() % 150) / 100.0f + 1.0f;
		float x = (rand() % 800) / 1000.0f - 0.4f;
		float y = (rand() % 800) / 1000.0f - 0.4f;
		teapot_translate.push_back(make_pair(glm::vec3(x, y, 0), alfa));
	}

}
void Tema2::Init()
{
	camera = new Laborator::MyCamera();
	camera->Set(glm::vec3(0, 2, 3.5f), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));
	
	vector<VertexFormat> vertices
	{
		VertexFormat(glm::vec3(0, 0, 0),glm::vec3(0), glm::vec3(1.0f, 0.75f, 0.79f)),
		VertexFormat(glm::vec3(-1, 0,  0),glm::vec3(0), glm::vec3(1.0f, 0.75f, 0.79f)),
		VertexFormat(glm::vec3(0, 0,  1),glm::vec3(0), glm::vec3(1.0f, 0.75f, 0.79f)),
		VertexFormat(glm::vec3(-1, 0,  1), glm::vec3(0),glm::vec3(1.0f, 0.75f, 0.79f)),
		VertexFormat(glm::vec3(0, -1,  0), glm::vec3(0),glm::vec3(1.0f, 0.75f, 0.79f)),
		VertexFormat(glm::vec3(-1, -1,  0),glm::vec3(0), glm::vec3(1.0f, 0.75f, 0.79f)),
		VertexFormat(glm::vec3(0, -1,  1), glm::vec3(0), glm::vec3(1.0f, 0.75f, 0.79f)),
		VertexFormat(glm::vec3(-1, -1,  1), glm::vec3(0), glm::vec3(1.0f, 0.75f, 0.79f))
	};

	vector<unsigned short> indices =
	{
		0, 1, 2,
		1, 3, 2,
		2, 3, 7,
		2, 7, 6,
		1, 7, 3,
		1, 5, 7,
		6, 7, 4,
		7, 5, 4,
		0, 4, 1,
		1, 4, 5,
		2, 6, 4,
		0, 2, 4
	};


	CreateMesh("cube", vertices, indices);

	vertices.clear();
	indices.clear();
	
	Shader* shader = new Shader("ShaderTema2");
	shader->AddShader("Source/Laboratoare/Tema2/VertexShader.glsl", GL_VERTEX_SHADER);
	shader->AddShader("Source/Laboratoare/Tema2/FragmentShader.glsl", GL_FRAGMENT_SHADER);
	shader->CreateAndLink();
	shaders[shader->GetName()] = shader;

	init_cylindre(2.8f, vertices, indices);

	R = -3.0f;

	CreateMesh("cylindre", vertices, indices);

	vertices.clear();
	indices.clear();

	init_sphere(1.0f, vertices, indices);
	CreateMesh("sphere", vertices, indices);

	vertices.clear();
	indices.clear();

	vertices.push_back(VertexFormat(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0), glm::vec3(1, 1, 1)));
	vertices.push_back(VertexFormat(glm::vec3(0.2f, 0.0f, 0.0f), glm::vec3(0), glm::vec3(1, 1, 1)));
	vertices.push_back(VertexFormat(glm::vec3(0.2f, 0.2f, 0.0f), glm::vec3(0), glm::vec3(1, 1, 1)));
	vertices.push_back(VertexFormat(glm::vec3(0.0f, 0.2f, 0.0f), glm::vec3(0), glm::vec3(1, 1, 1)));
		
	indices.push_back(0);
	indices.push_back(1);
	indices.push_back(2);
	indices.push_back(2);
	indices.push_back(0);
	indices.push_back(3);

	CreateMesh("square", vertices, indices);

	vertices.clear();
	indices.clear();

	vertices.push_back(VertexFormat(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0), glm::vec3(0.14f, 0.44f, 0.63f)));
	vertices.push_back(VertexFormat(glm::vec3(0.2f, 0.0f, 0.0f), glm::vec3(0), glm::vec3(0.14f, 0.44f, 0.63f)));
	vertices.push_back(VertexFormat(glm::vec3(0.2f, 0.2f, 0.0f), glm::vec3(0), glm::vec3(0.14f, 0.44f, 0.63f)));
	vertices.push_back(VertexFormat(glm::vec3(0.0f, 0.2f, 0.0f), glm::vec3(0), glm::vec3(0.14f, 0.44f, 0.63f)));

	indices.push_back(0);
	indices.push_back(1);
	indices.push_back(2);
	indices.push_back(2);
	indices.push_back(0);
	indices.push_back(3);
	
	CreateMesh("square2", vertices, indices);

	vertices.clear();
	indices.clear();

	vertices.push_back(VertexFormat(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0), glm::vec3(1, 1, 1)));
	vertices.push_back(VertexFormat(glm::vec3(0.0f, 0.0f, 0.2f), glm::vec3(0), glm::vec3(1, 1, 1)));
	vertices.push_back(VertexFormat(glm::vec3(0.0f, 0.2f, 0.2f), glm::vec3(0), glm::vec3(1, 1, 1)));
	vertices.push_back(VertexFormat(glm::vec3(0.0f, 0.2f, 0.0f), glm::vec3(0), glm::vec3(1, 1, 1)));

	indices.push_back(0);
	indices.push_back(1);
	indices.push_back(2);
	indices.push_back(2);
	indices.push_back(0);
	indices.push_back(3);

	CreateMesh("square3", vertices, indices);

	vertices.clear();
	indices.clear();

	vertices.push_back(VertexFormat(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0), glm::vec3(0.14f, 0.44f, 0.63f)));
	vertices.push_back(VertexFormat(glm::vec3(0.0f, 0.0f, 0.2f), glm::vec3(0), glm::vec3(0.14f, 0.44f, 0.63f)));
	vertices.push_back(VertexFormat(glm::vec3(0.0f, 0.2f, 0.2f), glm::vec3(0), glm::vec3(0.14f, 0.44f, 0.63f)));
	vertices.push_back(VertexFormat(glm::vec3(0.0f, 0.2f, 0.0f), glm::vec3(0), glm::vec3(0.14f, 0.44f, 0.63f)));

	indices.push_back(0);
	indices.push_back(1);
	indices.push_back(2);
	indices.push_back(2);
	indices.push_back(0);
	indices.push_back(3);

	CreateMesh("square4", vertices, indices);

	Mesh* mesh = new Mesh("Teapot");
	mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "teapot.obj");
	meshes[mesh->GetMeshID()] = mesh;

	nb_clouds = 10;
	nb_spheres = 8;
	nb_teapots = 5;
	gen_values();

	lightPosition = glm::vec3(0, 1, 1);
	materialShininess = 30;
	materialKd = 0.5;
	materialKs = 0.5;

	for (int i = 0; i < nb_spheres; i++) {
		colision_sphere.push_back(false);
		exist_sphere.push_back(true);
	}

	scale_for_combustible = 6.0f;
	copy_for_scale = scale_for_combustible;

	for (int i = 0; i < nb_teapots; i++) {
		exist_teapot.push_back(vector<bool>());
		for (int j = 0; j < teapots_per_slice[i]; j++) {
			exist_teapot[i].push_back(true);
		}
	}

	life_spheres = 2;
	for (int i = 0; i < life_spheres; i++) {
		exist_good_sphere.push_back(true);
	}

	cubes = 2;
	for (int i = 0; i < cubes; i++) {
		exist_cube.push_back(true);
	}
	rot_alfa = 0.3f;
	copy_rot_alfa = rot_alfa;

	speed_rotate_plane = 2.0f;
	copy_speed_rotate_plane = speed_rotate_plane;
	speed_rotate_sea = 3.0f;
	copy_speed_rotate_sea = speed_rotate_sea;

	projectionMatrix = glm::perspective(RADIANS(60), window->props.aspectRatio, 0.01f, 200.0f);

}
void Tema2::merge_circles(vector<VertexFormat>& vertices, vector<unsigned short>& indices, int start1, int start2) {
	
	for (int i = 1; i <= 100; i++) {
		indices.push_back(start1 + i);
		indices.push_back(start2 + i);
		indices.push_back(start1 + (i + 1) % 100);

		indices.push_back(start1 + (i + 1) % 100);
		indices.push_back(start2 + i);
		indices.push_back(start2 + (i + 1) % 100);

	}
	
}
void Tema2::init_circle(float radius, vector<VertexFormat>& vertices, vector<unsigned short>& indices, glm::vec3& center, int start) {

	float y = 1.0, x = 0.0;
	float step = 2 * M_PI / 100;
	float teta = 0.0f;
	float z = center.z;
	int def = rand() % 8 + 2;
	int n = 100 * def;
	vertices.push_back(VertexFormat(glm::vec3(center.x, center.y, z), glm::vec3(0), glm::vec3(0.125f, 0.69f, 0.66f)));
	for (int i = 0; i < 100; i++) {
		teta += step;
		float alfa = (rand() % n) / 1000.0f - def / 20.0f;
		vertices.push_back(VertexFormat(glm::vec3(center.x + (radius + alfa) * cos(teta), center.y + (radius + alfa) * sin(teta), z), glm::vec3(0), 
			glm::vec3(0.125f, 0.69f, 0.66f)));
	}

	for (int i = 1; i <= 100; i++) {
		indices.push_back(0 + start);
		indices.push_back(i + start);
		indices.push_back((i + 1) % 100 + start);
	}

}

void Tema2::init_cylindre(float radius, vector<VertexFormat>& vertices, vector<unsigned short>& indices) {
	for (int i = 0; i < 40; i++) {
		init_circle(radius, vertices, indices, glm::vec3(0, -radius - 0.2f, i * -0.25f), 101 * i);
	}
	for (int i = 0; i < 39; i++) {
		merge_circles(vertices, indices, i * 101, (i + 1) * 101);
	}
}

void Tema2::init_sphere(float radius, std::vector<VertexFormat>& vertices, std::vector<unsigned short>& indices) {
	float sector_step = 2 * M_PI / 100;
	float stack_step = M_PI / 100;
	int def = rand() % 8 + 2;
	int n = 100 * def;
	for (int i = 0; i <= 100; i++) {
		float alfa = (rand() % n) / 1000.0f - def / 20.0f;
		float phi = M_PI / 2 - i * stack_step;
		float common = (radius + alfa) * cos(phi);
		float z = (radius + alfa) * sin(phi);
		for (int j = 0; j <= 100; j++) {
			float tetha = j * sector_step;
			float x = common * cos(tetha);
			float y = common * sin(tetha);
			vertices.push_back(VertexFormat(glm::vec3(x, y, z), glm::vec3(0), glm::vec3(1, 0, 0)));
		}
	}
	for (int i = 0; i < 100; i++) {
		int start1 = i * 101;
		int start2 = (i + 1) * 101;
		for (int j = 0; j < 100; j++) {
			if (i != 0) {
				indices.push_back(start1 + j);
				indices.push_back(start2 + j);
				indices.push_back(start1 + j + 1);
			}

			if (i != 99) {
				indices.push_back(start1 + j + 1);
				indices.push_back(start2 + j);
				indices.push_back(start2 + j + 1);
			}
		}
	}
}


void Tema2::draw_cube(int i, float angle) {
	glm::vec3 center_initial(-1 / 2.0, -1 / 2.0, 1 / 2.0);
	glm::mat4 modelMatrix = glm::mat4(1);

	modelMatrix = Transform3D::Translate(0, -3, 0) * Transform3D::RotateOZ(angle) * Transform3D::Translate(0, 3, 0) *
		Transform3D::Translate(3 + copy_for_clouds[4 * i + 1], 2.0f + copy_for_clouds[4 * i + 2], 0.0f) * Transform3D::RotateOY(RADIANS(80.0f)) * Transform3D::Scale(0.2f, 0.2f, 0.2f);

	glm::vec4 center = modelMatrix * glm::vec4(center_initial, 1);

	modelMatrix = Transform3D::Translate(center.x, center.y, center.z) * Transform3D::RotateOZ(2 * angle) * Transform3D::Translate(-center.x, -center.y, -center.z) *
		modelMatrix;

	center = modelMatrix * glm::vec4(center_initial, 1);
	if (exist_cube[i]) {
		RenderSimpleMesh(meshes["cube"], shaders["ShaderTema2"], modelMatrix, glm::vec3(0.0f, 1.0f, 0.0f));
		if (colision(radius_sphere, glm::vec3(center_sphere.x, center_sphere.y, center_sphere.z),
			0.1f, glm::vec3(center.x, center.y, center.z)) && !lost) {
			invincible = true;
			exist_cube[i] = false;
			cubes--;
			num2++;
		}
	}
	if (!exist_cube[i] && center.x >= 0.0f && center.y <= 0.0f) {
		exist_cube[i] = true;
	}
	
}
void Tema2::draw_sphere(int i, float angle, glm::vec3& translate, bool good) {

	glm::vec3 center_initial(0, 0, 0);
	
	glm::mat4 modelMatrix = Transform3D::Translate(0, -3, 0) * Transform3D::RotateOZ(angle) * Transform3D::Translate(0, 3, 0) *
		Transform3D::Translate(4 + translate.x, 0.3f + -6.5f + translate.y, 0 + translate.z) * Transform3D::Scale(0.1f, 0.1f, 0.1f);

	glm::vec4 center = modelMatrix * glm::vec4(center_initial, 1);

	modelMatrix = Transform3D::Translate(center.x, center.y, center.z) * Transform3D::RotateOX(2 * angle) * Transform3D::Translate(-center.x, -center.y, -center.z) *
		modelMatrix;

	center = modelMatrix * glm::vec4(center_initial, 1);
	if (!good) {
		if (exist_sphere[i]) {
			RenderSimpleMesh(meshes["sphere"], shaders["ShaderTema2"], modelMatrix, glm::vec3(1, 0, 0));
			if (colision(radius_sphere, glm::vec3(center_sphere.x, center_sphere.y, center_sphere.z), 0.1f,
				glm::vec3(center.x, center.y, center.z)) && !lost && !invincible) {
				exist_sphere[i] = false;
				lifes--;
				if (lifes == 0) {
					lost = true;
				}
			}
		}
		if (!exist_sphere[i] && center.x >= 0.0f && center.y <= 0.0f) {
			exist_sphere[i] = true;
		}
	}
	else {
		if (exist_good_sphere[i]) {
			RenderSimpleMesh(meshes["sphere"], shaders["ShaderTema2"], modelMatrix, glm::vec3(241 / 255.0, 196 / 255.0, 15 / 255.0));
			if (colision(radius_sphere, glm::vec3(center_sphere.x, center_sphere.y, center_sphere.z), 0.1f,
				glm::vec3(center.x, center.y, center.z)) && !lost) {
				exist_good_sphere[i] = false;
				lifes++;
				num++;
				life_spheres--;
			}
		}
		if (!exist_good_sphere[i] && center.x >= 0.0f && center.y <= 0.0f) {
			exist_good_sphere[i] = true;
		}
	}
	

}

Mesh* Tema2::CreateMesh(const char* name, const std::vector<VertexFormat>& vertices, const std::vector<unsigned short>& indices)
{
	unsigned int VAO = 0;
	//Create the VAO and bind it
	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);
	//Create the VBO and bind it
	unsigned int VBO = 0;
	glGenBuffers(1, &VBO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	//Send vertices data into the VBO buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices[0]) * vertices.size(), &vertices[0], GL_STATIC_DRAW);
	//Create the IBO and bind it
	unsigned int IBO = 0;
	glGenBuffers(1, &IBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);
	//Send indices data into the IBO buffer
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices[0]) * indices.size(), &indices[0], GL_STATIC_DRAW);
	// set vertex position attribute
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), 0);
	// set vertex normal attribute
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(sizeof(glm::vec3)));
	// set texture coordinate attribute
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(2 * sizeof(glm::vec3)));
	// set vertex color attribute
	glEnableVertexAttribArray(3);
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(2 * sizeof(glm::vec3) + sizeof(glm::vec2)));
	// Unbind the VAO
	glBindVertexArray(0);
	
	CheckOpenGLError();

	// Mesh information is saved into a Mesh object
	meshes[name] = new Mesh(name);
	meshes[name]->InitFromBuffer(VAO, static_cast<unsigned short>(indices.size()));
	return meshes[name];
}

void Tema2::init_cloud(float angle, glm::vec3& translate) {
	glm::vec3 center_initial(-1 / 2.0, -1 / 2.0, 1 / 2.0);
	glm::mat4 modelMatrix = glm::mat4(1);

	modelMatrix = Transform3D::Translate(0, -3, 0) * Transform3D::RotateOZ(angle) * Transform3D::Translate(0, 3, 0) *
		Transform3D::Translate(3 + translate.x, 2.0f + translate.y, -2.0f + translate.z) * Transform3D::RotateOY(RADIANS(80.0f)) * Transform3D::Scale(0.2f, 0.2f, 0.2f);

	glm::vec4 center = modelMatrix * glm::vec4(center_initial, 1);

	modelMatrix = Transform3D::Translate(center.x, center.y, center.z) * Transform3D::RotateOZ(2 * angle) * Transform3D::Translate(-center.x, -center.y, -center.z) *
		modelMatrix;
	RenderSimpleMesh(meshes["cube"], shaders["ShaderTema2"], modelMatrix, glm::vec3(1.0f, 0.75f, 0.79f));

	modelMatrix = glm::mat4(1);
	modelMatrix = Transform3D::Translate(0, -3, 0) * Transform3D::RotateOZ(angle) * Transform3D::Translate(0, 3, 0)
		* Transform3D::Translate(3.1f + translate.x, 1.95f + translate.y, -2.05f + translate.z) * Transform3D::RotateOY(RADIANS(-20.0f)) * Transform3D::Scale(0.1f, 0.1f, 0.1f);
	RenderSimpleMesh(meshes["cube"], shaders["ShaderTema2"], modelMatrix, glm::vec3(1.0f, 0.75f, 0.79f));

	modelMatrix = glm::mat4(1);
	modelMatrix = Transform3D::Translate(0, -3, 0) * Transform3D::RotateOZ(angle) * Transform3D::Translate(0, 3, 0)
		* Transform3D::Translate(3.1f + translate.x, 1.95f + translate.y, -1.8f + translate.z) * Transform3D::RotateOX(RADIANS(-20.0f)) * Transform3D::Scale(0.1f, 0.1f, 0.1f);
	RenderSimpleMesh(meshes["cube"], shaders["ShaderTema2"], modelMatrix, glm::vec3(1.0f, 0.75f, 0.79f));

	modelMatrix = glm::mat4(1);
	modelMatrix = Transform3D::Translate(0, -3, 0) * Transform3D::RotateOZ(angle) * Transform3D::Translate(0, 3, 0) *
		Transform3D::Translate(3.1f + translate.x, 2.05f + translate.y, -1.92f + translate.z) * Transform3D::RotateOZ(RADIANS(-45.0f)) * Transform3D::Scale(0.1f, 0.1f, 0.1f);
	RenderSimpleMesh(meshes["cube"], shaders["ShaderTema2"], modelMatrix, glm::vec3(1.0f, 0.75f, 0.79f));
}

void Tema2::init_clouds(float angle) {
	for (int i = 0; i < nb_clouds; i++) {
		float ang = angle * for_clouds[4 * i];
		float x = for_clouds[4 * i + 1];
		float y = for_clouds[4 * i + 2];
		float z = for_clouds[4 * i + 3];
		glm::vec3 translate(x, y, z);
		init_cloud(ang, translate);
	}
}

void Tema2::draw_spheres(float angle) {
	for (int i = 0; i < nb_spheres; i++) {
		float ang = angle * for_spheres[4 * i];
		float x = for_spheres[4 * i + 1];
		float y = for_spheres[4 * i + 2];
		float z = for_spheres[4 * i + 3];
		glm::vec3 translate(x, y, z);
		draw_sphere(i, ang, translate, false);
	}
}

void Tema2::draw_slice_teapot(int k, int nb, glm::vec3 &translate, float angle) {
	for (int i = 0; i < nb; i++) {
		glm::vec3 center_initial(0, 0, 0);
		
		glm::mat4 modelMatrix = Transform3D::Translate(0, -3, 0) * Transform3D::RotateOZ(angle) * Transform3D::Translate(0, 3, 0) *
			Transform3D::Translate(inital_translate_teapot[i].x + translate.x, inital_translate_teapot[i].y + translate.y, inital_translate_teapot[i].z + translate.z) * Transform3D::Scale(0.2f, 0.2f, 0.2f);

		glm::vec4 center = modelMatrix * glm::vec4(center_initial, 1);

		modelMatrix = Transform3D::Translate(center.x, center.y, center.z) * Transform3D::RotateOX(2 * angle) * Transform3D::Translate(-center.x, -center.y, -center.z) *
			modelMatrix;
		
		center = modelMatrix * glm::vec4(center_initial, 1);
		if (exist_teapot[k][i]) {
			RenderSimpleMesh(meshes["Teapot"], shaders["ShaderTema2"], modelMatrix, glm::vec3(0.25f, 0.87f, 0.81f));
			if (colision(radius_sphere, glm::vec3(center_sphere.x, center_sphere.y, center_sphere.z), 0.1f,
				glm::vec3(center.x, center.y, center.z)) && !lost) {
				exist_teapot[k][i] = false;
				scale_for_combustible = MIN(scale_for_combustible + 0.2f, copy_for_scale);
			}
		}

		if (!exist_teapot[k][i] && center.x >= 0.0f && center.y <= 0.0f) {
			exist_teapot[k][i] = true;
		}
		
	}
	
}

void Tema2::draw_teapots(float angle) {
	for (int i = 0; i < nb_teapots; i++) {
		draw_slice_teapot(i, teapots_per_slice[i], teapot_translate[i].first, angle * teapot_translate[i].second);
	}
}

void Tema2::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(1.0f, 0.62f, 0.47f, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

void Tema2::draw_plane(float angle, float deltaTimeSeconds) {
	glm::mat4 modelMatrix = glm::mat4(1);
	glm::vec3 center_initial(-1 / 2.0, -1 / 2.0, 1 / 2.0);
	if (lost) {
		rotate_plane_end = MIN(rotate_plane_end + 1 / 60.0f * 1.5f, RADIANS(90));
		time += deltaTimeSeconds;
	}
	if (contor >= wait_time) {
		if (angle_plane < 0) {
			angle_plane = angle_plane + 1 / 60.0f * 1.5f;
			if (angle_plane >= 0.0) {
				angle_plane = 0.0f;
				contor = 0;
			}
		}
		if (angle_plane > 0) {
			angle_plane = angle_plane - 1 / 60.0f * 1.5f;
			if (angle_plane <= 0.0) {
				angle_plane = 0.0f;
				contor = 0;
			}
		}
	}
	if (angle_plane != angle_plane_prev) {
		angle_plane_prev = angle_plane;
	}
	else {
		contor++;
		
	}
	modelMatrix = Transform3D::Translate(0, dy, 0) * Transform3D::Translate(0, 2, 0) * Transform3D::RotateOZ(RADIANS(-5.0f)) * Transform3D::Scale(0.6f, 0.2f, 0.2f);
	glm::vec4 center_rot = modelMatrix * glm::vec4(center_initial, 1);
	glm::mat4 end_matrix = Transform3D::Translate(0, -7.0f * time * (time - deltaTimeSeconds), 0) * Transform3D::Translate(center_rot.x, center_rot.y, center_rot.z) * Transform3D::RotateOZ(-rotate_plane_end) *
		Transform3D::Translate(-center_rot.x, -center_rot.y, -center_rot.z);
	glm::mat4 rot_matrix = Transform3D::Translate(center_rot.x, center_rot.y, center_rot.z) * Transform3D::RotateOX(angle_plane) * Transform3D::Translate(-center_rot.x, -center_rot.y, -center_rot.z);
	if (!lost) {
		modelMatrix = rot_matrix * modelMatrix;
	}
	else {
		modelMatrix = end_matrix * modelMatrix;
		center_rot = modelMatrix * glm::vec4(center_initial, 1);
		if (center_rot.y <= -4.0f) {
			end_game = true;
		}
	}
	
	RenderSimpleMesh(meshes["cube"], shaders["ShaderTema2"], modelMatrix, glm::vec3(0.9f, 0.29f, 0.23f));

	modelMatrix = Transform3D::Translate(0, dy, 0) * Transform3D::Translate(0.2f, 2, 0) * Transform3D::RotateOZ(RADIANS(-5.0f)) * Transform3D::Scale(0.2f, 0.22f, 0.2f);
	if (!lost) {
		modelMatrix = rot_matrix * modelMatrix;
		center_sphere = modelMatrix * glm::vec4(center_initial, 1);
	}
	else {
		modelMatrix = end_matrix * modelMatrix;
	}
	
	RenderSimpleMesh(meshes["cube"], shaders["ShaderTema2"], modelMatrix, glm::vec3(1.0f, 1.0f, 1.0f));
	
	modelMatrix = Transform3D::Translate(0, dy, 0) * Transform3D::Translate(-0.2f, 2.0f, 0.2f) * Transform3D::RotateOZ(RADIANS(-7.0f)) * Transform3D::Scale(0.08f, 0.05f, 0.4f);
	if (!lost) {
		modelMatrix = rot_matrix * modelMatrix;
	}
	else {
		modelMatrix = end_matrix * modelMatrix;
	}
	
	RenderSimpleMesh(meshes["cube"], shaders["ShaderTema2"], modelMatrix, glm::vec3(0.9f, 0.29f, 0.23f));

	modelMatrix = Transform3D::Translate(0, dy, 0) * Transform3D::Translate(-0.2f, 2.0f, -0.4f) * Transform3D::RotateOZ(RADIANS(-7.0f)) * Transform3D::Scale(0.08f, 0.05f, 0.4f);
	if (!lost) {
		modelMatrix = rot_matrix * modelMatrix;
	}
	else {
		modelMatrix = end_matrix * modelMatrix;
	}
	RenderSimpleMesh(meshes["cube"], shaders["ShaderTema2"], modelMatrix, glm::vec3(0.9f, 0.29f, 0.23f));

	modelMatrix = Transform3D::Translate(0, dy, 0) * Transform3D::Translate(-0.6f, 2.12f, 0.05f) * Transform3D::RotateOZ(RADIANS(-0.0f)) * Transform3D::Scale(0.02f, 0.1f, 0.1f);
	if (!lost) {
		modelMatrix = rot_matrix * modelMatrix;
	}
	else {
		modelMatrix = end_matrix * modelMatrix;
	}
	RenderSimpleMesh(meshes["cube"], shaders["ShaderTema2"], modelMatrix, glm::vec3(0.9f, 0.29f, 0.23f));


	modelMatrix = Transform3D::Translate(0, dy, 0) * Transform3D::Translate(0.23f, -0.1f + 2, 0.05f) * Transform3D::RotateOZ(RADIANS(-5.0f)) * Transform3D::Scale(0.05f, 0.05f, 0.05f);
	glm::vec4 center = modelMatrix * glm::vec4(center_initial, 1);
	if (first_person) {
		event_first += MIN(10, event_first + 1);
		if (event_first == 1) {
			camera->Set(glm::vec3(center_rot.x - 0.4f, center_rot.y + 0.3f, center_rot.z), glm::vec3(center.x + 1.0f, center.y + 0.1f, center.z), glm::vec3(0, 1, 0));
		}
		else {
			camera->TranslateUpword(dy - old_dy);
			old_dy = dy;
		}
	}
	if (!lost) {
		modelMatrix = rot_matrix * modelMatrix;
	}
	else {
		modelMatrix = end_matrix * modelMatrix;
	}
	RenderSimpleMesh(meshes["cube"], shaders["ShaderTema2"], modelMatrix, glm::vec3(0.9f, 0.29f, 0.23f));

	modelMatrix = Transform3D::Translate(0, dy, 0) * Transform3D::Translate(0.25f, -0.1f + 2, -0.05f) * Transform3D::RotateOZ(RADIANS(0.0f)) * Transform3D::Scale(0.08f, 0.05f, 0.3f);
	if (!lost) {
		modelMatrix = Transform3D::Translate(center.x, center.y, center.z) * Transform3D::RotateOX(speed_rotate_plane * angle) * Transform3D::Translate(-center.x, -center.y, -center.z) *
			modelMatrix;
		modelMatrix = rot_matrix * modelMatrix;
	}
	else {
		modelMatrix = end_matrix * modelMatrix;
	}
	
	RenderSimpleMesh(meshes["cube"], shaders["ShaderTema2"], modelMatrix, glm::vec3(0.95f, 0.61f, 0.07f));

	modelMatrix = Transform3D::Translate(0, dy, 0) * Transform3D::Translate(0.30f, -0.27f + 2, 0.07f) * Transform3D::RotateOX(RADIANS(-90.0f)) * Transform3D::Scale(0.08f, 0.05f, 0.3f);
	if (!lost) {
		modelMatrix = Transform3D::Translate(center.x, center.y, center.z) * Transform3D::RotateOX(speed_rotate_plane * angle) * Transform3D::Translate(-center.x, -center.y, -center.z) *
			modelMatrix;
		modelMatrix = rot_matrix * modelMatrix;
	}
	else {
		modelMatrix = end_matrix * modelMatrix;
	}
	RenderSimpleMesh(meshes["cube"], shaders["ShaderTema2"], modelMatrix, glm::vec3(0.95f, 0.61f, 0.07f));
}

void Tema2::draw_life() {
	if (!first_person) {
		for (int i = 0; i < lifes; i++) {
			glm::mat4 modelMatrix = Transform3D::Translate(-3 + i / 6.0, 2.7, 0) * Transform3D::Scale(0.04f, 0.04f, 0.04f);
			RenderSimpleMesh(meshes["sphere"], shaders["ShaderTema2"], modelMatrix, glm::vec3(1, 0, 0));
		}
	}
	
	if (first_person) {
		for (int i = 0; i < lifes; i++) {
			glm::mat4 modelMatrix = Transform3D::Translate(3, 1.6, -3 + i / 6.0) * Transform3D::Scale(0.05f, 0.05f, 0.05f);
			RenderSimpleMesh(meshes["sphere"], shaders["ShaderTema2"], modelMatrix, glm::vec3(1, 0, 0));
		}
	}
}

void Tema2::draw_combustible() {
	if (!first_person) {
		if (scale_for_combustible <= 0.0f) {
			lost = true;
			glm::mat4 modelMatrix = Transform3D::Translate(2.0f, 2.6f, 0) * Transform3D::RotateOX(RADIANS(-15.0F)) * Transform3D::Scale(copy_for_scale, 1.0f, 1.0f);
			RenderSimpleMesh(meshes["square"], shaders["ShaderTema2"], modelMatrix, glm::vec3(1, 1, 1));
			return;
		}
		glm::mat4 modelMatrix = Transform3D::Translate(2.0f, 2.6f, 0) * Transform3D::RotateOX(RADIANS(-15.0F)) * Transform3D::Scale(scale_for_combustible, 1.0f, 1.0f);
		RenderSimpleMesh(meshes["square2"], shaders["VertexNormal"], modelMatrix, glm::vec3(0.14f, 0.44f, 0.63f));

		modelMatrix = Transform3D::Translate(2.0f, 2.6f, 0) * Transform3D::RotateOX(RADIANS(-15.0F)) * Transform3D::Scale(copy_for_scale, 1.0f, 1.0f);
		RenderSimpleMesh(meshes["square"], shaders["ShaderTema2"], modelMatrix, glm::vec3(1, 1, 1));
	}
	else {
		if (scale_for_combustible <= 0.0f) {
			lost = true;
			glm::mat4 modelMatrix = Transform3D::Translate(2.0f, 1.5f, 0.5f) * Transform3D::RotateOX(RADIANS(-0.0F)) * Transform3D::Scale(1.0, 0.5f, copy_for_scale / 2.0);
			RenderSimpleMesh(meshes["square3"], shaders["ShaderTema2"], modelMatrix, glm::vec3(1, 1, 1));
			return;
		}
		glm::mat4 modelMatrix = Transform3D::Translate(2.0f, 1.5f, 0.5f) * Transform3D::RotateOX(RADIANS(-0.0F)) * Transform3D::Scale(1.0f, 0.5f, scale_for_combustible / 2.0);
		RenderSimpleMesh(meshes["square4"], shaders["VertexNormal"], modelMatrix, glm::vec3(0.14f, 0.44f, 0.63f));

		modelMatrix = Transform3D::Translate(2.0f, 1.5f, 0.5f) * Transform3D::RotateOX(RADIANS(-0.0F)) * Transform3D::Scale(1.0f, 0.5f, copy_for_scale / 2.0);
		RenderSimpleMesh(meshes["square3"], shaders["ShaderTema2"], modelMatrix, glm::vec3(1, 1, 1));
	}
}
bool Tema2::colision(float r1, glm::vec3 &center1, float r2, glm::vec3 &center2) {
	float distance = sqrt((center1.x - center2.x) * (center1.x - center2.x) +
		(center1.y - center2.y) * (center1.y - center2.y) +
		(center1.z - center2.z) * (center1.z - center2.z));
	return distance < (r1 + r2);
}
void Tema2::Update(float deltaTimeSeconds)
{
	if (!end_game) {
		glm::vec3 center_initial(-1 / 2.0, -1 / 2.0, 1 / 2.0);

		step_translate += rot_alfa * deltaTimeSeconds;
		scale_for_combustible -= deltaTimeSeconds * 0.2f;

		glm::ivec2 resolution = window->GetResolution();
		Time += deltaTimeSeconds;
		if (invincible) {
			time_invincible += deltaTimeSeconds;
			if (time_invincible >= 10.0f) {
				time_invincible = 0.0f;
				invincible = false;
			}
		}
		
		for (int i = 0; i < life_spheres; i++) {
			if (Time >= 60 * (i + num)) {
				draw_sphere(i, 4 * step_translate, glm::vec3(0, 0, 0), true);
			}
			
		}

		for (int i = 0; i < cubes; i++) {
			if (Time >= 20 * (i + num2)) {
				draw_cube(i, 3 * step_translate);
			}
		}
		
		init_clouds(step_translate);
		draw_spheres(step_translate / 2);
		draw_teapots(step_translate);
		glm::mat4 modelMatrix = Transform3D::Translate(0, R, 0) * Transform3D::RotateOZ(step_translate * speed_rotate_sea) * Transform3D::Translate(0, -R, 0);
		RenderSimpleMesh(meshes["cylindre"], shaders["ShaderTema2"], modelMatrix, glm::vec3(0.125f, 0.69f, 0.66f));
		draw_plane(-10 * step_translate, deltaTimeSeconds);
		draw_combustible();
		draw_life();
	}
}

void Tema2::FrameEnd()
{

}

void Tema2::RenderSimpleMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, glm::vec3 &color)
{
	if (!mesh || !shader || !shader->program)
		return;

	// render an object using the specified shader and the specified position
	shader->Use();

	int id = shader->GetProgramID();
	int location = glGetUniformLocation(id, "light_position");
	glUniform3fv(location, 1, glm::value_ptr(lightPosition));
	// Set eye position (camera position) uniform
	glm::vec3 eyePosition = -camera->position;
	location = glGetUniformLocation(id, "eye_position");
	glUniform3fv(location, 1, glm::value_ptr(eyePosition));
	// Set material property uniforms (shininess, kd, ks, object color) 
	location = glGetUniformLocation(id, "material_shininess");
	glUniform1i(location, materialShininess);

	location = glGetUniformLocation(id, "material_kd");
	glUniform1f(location, materialKd);

	location = glGetUniformLocation(id, "material_ks");
	glUniform1f(location, materialKs);

	location = glGetUniformLocation(id, "object_color");
	glUniform3fv(location, 1, glm::value_ptr(color));

	glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
	glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
	glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	mesh->Render();
}

void Tema2::OnInputUpdate(float deltaTime, int mods)
{
	// move the camera only if MOUSE_RIGHT button is pressed
	if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
	{
		float cameraSpeed = 2.0f;

		if (window->KeyHold(GLFW_KEY_W)) {
			//translate the camera forward
			camera->TranslateForward(deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_A)) {
			//translate the camera to the left
			camera->TranslateRight(-deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_S)) {
			//translate the camera backwards
			camera->TranslateForward(-deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_D)) {
			//translate the camera to the right
			camera->TranslateRight(deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_Q)) {
			//translate the camera down
			camera->TranslateUpword(-deltaTime * cameraSpeed);
		}

		if (window->KeyHold(GLFW_KEY_E)) {
			//translate the camera up
			camera->TranslateUpword(deltaTime * cameraSpeed);
		}
	}
	if (window->KeyHold(GLFW_KEY_Z)) {

		FOV += deltaTime * 1.0f;
		projectionMatrix = glm::perspective(FOV, window->props.aspectRatio, 0.01f, 200.0f);
	}
	if (window->KeyHold(GLFW_KEY_X)) {

		FOV -= deltaTime * 1.0f;
		projectionMatrix = glm::perspective(FOV, window->props.aspectRatio, 0.01f, 200.0f);
	}
	if (window->KeyHold(GLFW_KEY_G)) {
		scale_for_combustible -= 0.001f;
		rot_alfa = MIN(0.65f, rot_alfa + 0.001f);
	}
}

void Tema2::OnKeyPress(int key, int mods)
{
	//key press event
	
	if (key == GLFW_KEY_C) {
		first_person = !first_person;
		if (!first_person) {
			camera->Set(glm::vec3(0, 2, 3.5f), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));
		}
		else {
			event_first = 0;
		}
	}
}

void Tema2::OnKeyRelease(int key, int mods)
{
	// key release event
	if (key == GLFW_KEY_G) {
		rot_alfa = copy_rot_alfa;
	}
}

void Tema2::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// mouse move event
	if (!lost) {
		old_dy = dy;
		dy -= 1.5f * deltaY / 360.0f;
	}
	
	if (deltaY  > 0 && !lost) {
		if (contor >= wait_time) {
			contor = 0;
		}
		angle_plane = MAX(-M_PI / 4, angle_plane  - 1 / 60.0f * 1.5f);
	}
	if (deltaY  < 0 && !lost) {
		if (contor >= wait_time) {
			contor = 0;
		}
		angle_plane = MIN(M_PI / 4, angle_plane + 1 / 60.0f * 1.5f);
	}

}

void Tema2::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	
}

void Tema2::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	
}

void Tema2::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Tema2::OnWindowResize(int width, int height)
{
}
