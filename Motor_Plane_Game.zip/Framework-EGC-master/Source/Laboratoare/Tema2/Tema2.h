#pragma once
#include <Component/SimpleScene.h>
#include <Core/Engine.h>

#include "LabCamera.h"

#include <vector>

class Tema2 : public SimpleScene
{
public:
	Tema2();
	~Tema2();

	void Init() override;

private:
	void FrameStart() override;
	void Update(float deltaTimeSeconds) override;
	void FrameEnd() override;

	void RenderSimpleMesh(Mesh* mesh, Shader* shader, const glm::mat4& modelMatrix, glm::vec3 &color);

	void OnInputUpdate(float deltaTime, int mods) override;
	void OnKeyPress(int key, int mods) override;
	void OnKeyRelease(int key, int mods) override;
	void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
	void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
	void OnWindowResize(int width, int height) override;

	Mesh* CreateMesh(const char* name, const std::vector<VertexFormat>& vertices, const std::vector<unsigned short>& indices);
	void init_cloud(float angle, glm::vec3 &translate);
	void init_clouds(float angle);
	void gen_values();
	void init_circle(float radius, std::vector<VertexFormat>& vertices, std::vector<unsigned short>& indices, glm::vec3& center, int start);
	void merge_circles(std::vector<VertexFormat>& vertices, std::vector<unsigned short>& indices, int start1, int start2);
	void init_cylindre(float radius, std::vector<VertexFormat>& vertices, std::vector<unsigned short>& indices);
	void init_sphere(float radius, std::vector<VertexFormat>& vertices, std::vector<unsigned short>& indices);
	void draw_sphere(int i, float angle, glm::vec3& translate, bool good);
	void draw_spheres(float angle);
	void draw_slice_teapot(int i, int nb, glm::vec3& translate, float angle);
	void draw_teapots(float angle);
	void draw_plane(float angle, float deltaTimeSeconds);
	void draw_life();
	bool colision(float r1, glm::vec3& center1, float r2, glm::vec3& center2);
	void draw_combustible();
	void draw_cube(int i, float angle);

protected:
	Laborator::MyCamera* camera;
	glm::mat4 projectionMatrix;
	float FOV = RADIANS(60.f);
	float step_translate = 0.0f;
	float dy = 0.0f;
	float angle_plane = 0.0f;
	float angle_plane_prev = -1.0f;
	float Time = 0.0f;
	std::vector<float> for_clouds;
	std::vector<float> for_spheres;
	std::vector<int> teapots_per_slice;
	std::vector<glm::vec3> inital_translate_teapot;
	std::vector<std::vector<bool>> teapot_exist;
	std::vector<std::pair<glm::vec3, float>> teapot_translate;
	std::vector<bool> colision_sphere;
	std::vector<bool> exist_sphere;
	std::vector<bool> exist_good_sphere;
	std::vector<bool> exist_cube;
	std::vector<std::vector<bool>> exist_teapot;
	int nb_clouds;
	int nb_spheres;
	int nb_teapots;
	int contor = 0;
	int wait_time = 70;
	int lifes = 3;
	int num = 1;
	int contor2 = 0;
	float R;
	glm::vec3 lightPosition;
	glm::vec4 center_sphere;
	float radius_sphere = 0.22f;
	float scale_for_combustible;
	float copy_for_scale;
	float rotate_plane_end = 0.0f;
	float time = 0.0f;
	unsigned int materialShininess;
	float materialKd;
	float materialKs;
	float speed_rotate_plane;
	float copy_speed_rotate_plane;
	float speed_rotate_sea;
	float copy_speed_rotate_sea;
	std::vector<float> copy_for_clouds;
	std::vector<float> copy_for_spheres;
	bool lost = false;
	bool end_game = false;
	int life_spheres;
	int cubes;
	bool invincible = false;
	float time_invincible = 0.0f;
	int num2 = 1;
	float rot_alfa;
	float copy_rot_alfa;
	bool first_person = false;
	float old_dy = 0.0f;
	int event_first = 0;

};
