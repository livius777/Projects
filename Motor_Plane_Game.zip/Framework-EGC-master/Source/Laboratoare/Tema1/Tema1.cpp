#include "Tema1.h"

#include <vector>
#include <iostream>

#include <Core/Engine.h>
#include "Transform2D.h"

using namespace std;
	
Tema1::Tema1()
{
}

Tema1::~Tema1()
{
}
//functie care creeaza vertecsii si legaturile dintre triunghiuri pentru formarea unui cerc cu centrul in center, de raza radius
void Tema1::init_circle(float radius, vector<VertexFormat> &vertices, vector<unsigned short> &indices, glm::ivec2 &center) {
	
	float y = 1.0, x = 0.0;
	float step = 2 * M_PI / 100;
	float teta = 0.0f;

	vertices.push_back(VertexFormat(glm::vec3(center.x, center.y, 0), glm::vec3(1, 0, 0)));
	for (int i = 0; i < 100; i++) {
		teta += step;
		vertices.push_back(VertexFormat(glm::vec3(center.x + radius * cos(teta), center.y + radius * sin(teta), 0), glm::vec3(1, 0, 0)));
	}

	for (int i = 1; i < vertices.size() - 1; i++) {
		indices.push_back(0);
		indices.push_back(i);
		indices.push_back(i + 1);
	}
	indices.push_back(0);
	indices.push_back(vertices.size() - 1);
	indices.push_back(1);
}
//functie care determina daca un cerc se intersecteaza cu un dreptunghi vertical
//aceasta revine la a determina daca distanta dintre centrul cercului si punctul din interiorul dreptunghiului
//cel mai apropiat de centrul cercului este mai mica decat raza
bool Tema1::colision(float radius, glm::ivec2& center, glm::ivec2& left_corner, float width, float length) {
	float NearestX = MAX(left_corner.x, MIN(center.x, left_corner.x + width));
	float NearestY = MAX(left_corner.y, MIN(center.y, left_corner.y + length));
	float DeltaX = center.x - NearestX;
	float DeltaY = center.y - NearestY;
	return (DeltaX * DeltaX + DeltaY * DeltaY) < (radius * radius);
}
//initializari
void Tema1::init_values() {
	l = 100.0f;
	nb_forms = 11;
	dist_forms = 20.0f;
	tr_Ox = 0.0f;
	birdMatrix = Transform2D::Translate(50.0f, 400.0f);
	space = false;
	time = 0.0f;
	rotate_down = 0.0f;
	rotate_up = 0.0f;
	score = 0;
	step = 0;
	lost = false;
	gravity = 6.8f;
}
//construirea pasarii ce foloseste functia CreateMesh si init_circle
void Tema1::init_bird() {
	float body_edge = 20.0f;
	radius_bird = 3 * body_edge / 2;
	vector<VertexFormat> vertices;
	vector<unsigned short> indices;

	glm::ivec2 center(3 * body_edge / 4, body_edge / 4);

	init_circle(3.0f, vertices, indices, center);

	vector<VertexFormat> vertices2
	{
		VertexFormat(glm::vec3(- 3 * body_edge / 2, -body_edge / 2, 0), glm::vec3(0, 1, 0)),
		VertexFormat(glm::vec3(body_edge / 2, -body_edge / 2,  0), glm::vec3(0, 1, 0)),
		VertexFormat(glm::vec3(body_edge / 2, body_edge / 2,  0), glm::vec3(0, 1, 0)),
		VertexFormat(glm::vec3(- 3 * body_edge / 2, body_edge / 2,  0), glm::vec3(0, 1, 0)),
		VertexFormat(glm::vec3(3 * body_edge / 2, 0,  0), glm::vec3(0, 1, 0)),
		VertexFormat(glm::vec3(-body_edge, 3 * body_edge / 2,  0), glm::vec3(0, 1, 0)),
		VertexFormat(glm::vec3(-body_edge / 4, -body_edge / 2,  0), glm::vec3(0, 1, 0)),
		VertexFormat(glm::vec3(body_edge / 4, -body_edge / 2,  0), glm::vec3(0, 1, 0)),
		VertexFormat(glm::vec3(-body_edge / 2, -body_edge,  0), glm::vec3(0, 1, 0)),
		VertexFormat(glm::vec3(0, -body_edge,  0), glm::vec3(0, 1, 0)),
		VertexFormat(glm::vec3(body_edge / 2, -body_edge,  0), glm::vec3(0, 1, 0)),
		VertexFormat(glm::vec3(body_edge / 2, body_edge / 2,  0), glm::vec3(1, 0, 0)),
		VertexFormat(glm::vec3(-body_edge / 2, body_edge / 2,  0), glm::vec3(1, 0, 0)),
		VertexFormat(glm::vec3(0, 3 * body_edge / 2,  0), glm::vec3(1, 0, 0)),
		VertexFormat(glm::vec3(body_edge / 2, body_edge / 2,  0), glm::vec3(1, 0, 0)),
		VertexFormat(glm::vec3(-body_edge / 2, body_edge / 2,  0), glm::vec3(1, 0, 0)),
		VertexFormat(glm::vec3(-body_edge, 3 * body_edge / 2,  0), glm::vec3(1, 0, 0)),


	};
	vector<unsigned short> indices2 =
	{
		0, 1, 2,
		3, 0, 2,
		1, 2, 4,
		6, 8, 9,
		7, 9, 10, 
		11, 12, 13,
		14, 15, 16
	};
	for (int i = 0; i < vertices2.size(); i++) {
		vertices.push_back(vertices2[i]);
	}
	for (int i = 0; i < indices2.size(); i++) {
		indices.push_back(indices2[i] + 101);
	}

	vector<VertexFormat> vertices3;
	vector<unsigned short> indices3;

	glm::ivec2 c1(-body_edge / 4, -5 * body_edge / 4);
	init_circle(body_edge / 4, vertices3, indices3, c1);
	for (int i = 0; i < vertices3.size(); i++) {
		vertices.push_back(vertices3[i]);
	}
	for (int i = 0; i < indices3.size(); i++) {
		indices.push_back(indices3[i] + 118);
	}

	vector<VertexFormat> vertices4;
	vector<unsigned short> indices4;

	glm::ivec2 c2(body_edge / 4, -5 * body_edge / 4);
	init_circle(body_edge / 4, vertices4, indices4, c2);
	for (int i = 0; i < vertices4.size(); i++) {
		vertices.push_back(vertices4[i]);
	}
	for (int i = 0; i < indices4.size(); i++) {
		indices.push_back(indices4[i] + 219);
	}
	CreateMesh("bird", vertices, indices);
}
//creare patrat "mama" plus inaltimilor dreptunghiurilor si calcularea pozitiilor unde vor
//fi randate dreptunghiurile
void Tema1::Init()
{
	glm::ivec2 resolution = window->GetResolution();
	auto camera = GetSceneCamera();
	camera->SetOrthographic(0, (float)resolution.x, 0, (float)resolution.y, 0.01f, 400);
	camera->SetPosition(glm::vec3(0, 0, 50));
	camera->SetRotation(glm::vec3(0, 0, 0));
	camera->Update();
	GetCameraInput()->SetActive(false);

	init_values();
	
	vector<VertexFormat> vertices
	{
		VertexFormat(glm::vec3(0, 0, 0), glm::vec3(0, 0, 1)),
		VertexFormat(glm::vec3(l, 0,  0), glm::vec3(0, 0, 1)),
		VertexFormat(glm::vec3(l, l,  0), glm::vec3(0, 0, 1)),
		VertexFormat(glm::vec3(0, l,  0), glm::vec3(0, 0, 1)),
	};

	vector<unsigned short> indices =
	{
		0, 1, 2,
		3, 0, 2
	};
	
	CreateMesh("square_mother", vertices, indices);
	
	vector<float> s1{3.0f, 1.25f, 3.7f, 2.25f, 3.0f, 3.2f, 2.5f, 1.0f, 2.78f, 2.0f, 3.6f};
	vector<float> s2{2.0f, 1.75f, 1.0f, 1.8f, 2.6f, 1.15f, 2.5f, 2.6f, 1.78f, 0.75f, 0.5f};
	
	for (int i = 0; i < nb_forms; i++) {
		translate_OX.push_back((l + dist_forms) * i);
		scale_down.push_back(s1[i]);
		scale_up.push_back(s2[i]);
	}
	//pentru dreptunghiurile din a doua parte a "scenei duble"
	for (int i = 0; i < nb_forms; i++) {
		translate_OX.push_back((l + dist_forms) * (nb_forms + i));
	}

	init_bird();
}

void Tema1::FrameStart()
{
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	glViewport(0, 0, resolution.x, resolution.y);
}
//functia de creare a unui mesh de la laboratorul 2
Mesh* Tema1::CreateMesh(const char* name, const std::vector<VertexFormat>& vertices, const std::vector<unsigned short>& indices)
{
	unsigned int VAO = 0;
	
	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);
	
	unsigned int VBO = 0;
	glGenBuffers(1, &VBO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices[0]) * vertices.size(), &vertices[0], GL_STATIC_DRAW);
	
	unsigned int IBO = 0;
	glGenBuffers(1, &IBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, IBO);
	
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices[0]) * indices.size(), &indices[0], GL_STATIC_DRAW);
	
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), 0);

	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(sizeof(glm::vec3)));

	glEnableVertexAttribArray(2);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(2 * sizeof(glm::vec3)));

	glEnableVertexAttribArray(3);
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(VertexFormat), (void*)(2 * sizeof(glm::vec3) + sizeof(glm::vec2)));
	
	glBindVertexArray(0);
	CheckOpenGLError();

	meshes[name] = new Mesh(name);
	meshes[name]->InitFromBuffer(VAO, static_cast<unsigned short>(indices.size()));
	return meshes[name];
}

void Tema1::Update(float deltaTimeSeconds)
{
	if (!lost) {
		glm::ivec2 resolution = window->GetResolution();
		//resetam translatie pe Ox daca am translatat intreg ecranul
		if (tr_Ox >= resolution.x) {
			tr_Ox = 0;
			step = 0;
		}
		//crestere translatie, timp si rotatie
		tr_Ox += deltaTimeSeconds * 80.0f;
		time += deltaTimeSeconds;
		rotate_down += deltaTimeSeconds * 0.4f;
		//pasarea se roteste la maxim 90
		if (rotate_down >= M_PI / 2) {
			rotate_down = M_PI / 2;
		}
		//centrul pasarii
		glm::vec3 center = birdMatrix * glm::vec3(0, 0, 1);
		//nu mai rotim pasarea daca unghiul este mai mare sau egal cu 90
		if (rotate_down >= M_PI / 2) {
			birdMatrix = Transform2D::Translate(0, -gravity * time * (time - deltaTimeSeconds) / 2) * birdMatrix;
		}
		else { //altfel o rotim fata de centru
			birdMatrix = Transform2D::Translate(0, -gravity * time * (time - deltaTimeSeconds) / 2) * Transform2D::Translate(center.x, center.y) * Transform2D::Rotate(-deltaTimeSeconds * 0.4f) * Transform2D::Translate(-center.x, -center.y) * birdMatrix;
		}
		center = birdMatrix * glm::vec3(0, 0, 1);
		if (space) {
			//la apasarea space, translatam pasarea putin mai sus de unde cazuse si o rotim in sens trigonometric fata de cat se rotise in sens orar
			center = birdMatrix * glm::vec3(0, 0, 1);
			float ang = rotate_down;
			birdMatrix = Transform2D::Translate(0, gravity * time * (time - deltaTimeSeconds) / 2 + 50.0f) * Transform2D::Translate(center.x, center.y) * Transform2D::Rotate(ang) * Transform2D::Translate(-center.x, -center.y) * birdMatrix;
			space = false;
			time = 0.0f;
			rotate_down = 0.0f;
		}
		//desenare pasare
		RenderMesh2D(meshes["bird"], shaders["VertexColor"], birdMatrix);

		for (int i = 0; i < nb_forms; i++) {
			//desenare dreptunghiuri de jos
			modelMatrix = Transform2D::Translate(-tr_Ox, 0) * Transform2D::Scale(1, scale_down[i]) * Transform2D::Translate(translate_OX[i], 0) * glm::mat3(1);
			RenderMesh2D(meshes["square_mother"], shaders["VertexColor"], modelMatrix);
			glm::vec3 left_corner = modelMatrix * glm::vec3(0, 0, 1);
			glm::vec3 right_corner = modelMatrix * glm::vec3(l, l, 1);
			glm::ivec2 cent(center.x, center.y);
			glm::ivec2 lft(left_corner.x, left_corner.y);
			//verificare coliziune cu dreptunghiurile de jos
			if (colision(radius_bird, cent, lft, right_corner.x - left_corner.x, right_corner.y - left_corner.y)) {
				lost = true;
				break;
			}
			//cresc scorul daca am ajuns in interiorul obstacolului si doar o data pentru un obstacol
			if (left_corner.x <= center.x && step == i) {
				score += 10;
				step++;
				cout << "Score: " << score << endl;
			}
			//desenare dreptunghiuri de jos din a doua parte a "scenei duble"
			modelMatrix = Transform2D::Translate(-tr_Ox, 0) * Transform2D::Scale(1, scale_down[i]) * Transform2D::Translate(translate_OX[i + nb_forms], 0) * glm::mat3(1);
			RenderMesh2D(meshes["square_mother"], shaders["VertexColor"], modelMatrix);
			//desenare dreptunghiuri de sus din scena reala
			modelMatrix = Transform2D::Translate(-tr_Ox, 0) * Transform2D::Translate(translate_OX[i], 0) * Transform2D::Translate(0, resolution.y - l * scale_up[i]) * Transform2D::Scale(1, scale_up[i]) * glm::mat3(1);
			RenderMesh2D(meshes["square_mother"], shaders["VertexColor"], modelMatrix);

			glm::vec3 left_corner2 = modelMatrix * glm::vec3(0, 0, 1);
			glm::vec3 right_corner2 = modelMatrix * glm::vec3(l, l, 1);
			glm::ivec2 cent2(center.x, center.y);
			glm::ivec2 lft2(left_corner2.x, left_corner2.y);
			//verificare coliziune cu dreptunghiurile de sus
			if (colision(radius_bird, cent2, lft2, right_corner2.x - left_corner2.x, right_corner2.y - left_corner2.y)) {
				lost = true;
				break;
			}
			//desenare dreptunghiuri de sus din "a doua parte a scenei"
			modelMatrix = Transform2D::Translate(-tr_Ox, 0) * Transform2D::Translate(translate_OX[i + nb_forms], 0) * Transform2D::Translate(0, resolution.y - l * scale_up[i]) * Transform2D::Scale(1, scale_up[i]) * glm::mat3(1);
			RenderMesh2D(meshes["square_mother"], shaders["VertexColor"], modelMatrix);

		}
		if (lost) {
			cout << "Game Over! " << endl;

			cout << endl << "*********************************************" << endl << "Congratulations! You obtained the score: " << score << endl;
		}
	}
}

void Tema1::FrameEnd()
{

}

void Tema1::OnInputUpdate(float deltaTime, int mods)
{

}

void Tema1::OnKeyPress(int key, int mods)
{
	// add key press event
	if (key == GLFW_KEY_SPACE) {
		space = true;
	}
}

void Tema1::OnKeyRelease(int key, int mods)
{
	// add key release event
	
}

void Tema1::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event
}

void Tema1::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void Tema1::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Tema1::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Tema1::OnWindowResize(int width, int height)
{
}
